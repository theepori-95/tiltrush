export function normalizeTilt(
  gamma: number,
  neutralRoll: number = 0,
  sensitivity: "low" | "medium" | "high" = "medium"
): number {
  const diff = gamma - neutralRoll;
  // Deadzone around neutral
  if (Math.abs(diff) < 1.5) return 0;

  const maxAngle = sensitivity === "low" ? 35 : sensitivity === "high" ? 18 : 25;
  const clamped = Math.max(-maxAngle, Math.min(maxAngle, diff));
  return Number((clamped / maxAngle).toFixed(3));
}

export function generateRoomCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export function checkAABBCollision(
  pLeft: number,
  pRight: number,
  pTop: number,
  pBottom: number,
  oLeft: number,
  oRight: number,
  oTop: number,
  oBottom: number
): boolean {
  return !(pRight < oLeft || pLeft > oRight || pBottom < oTop || pTop > oBottom);
}

export function checkCircleCollision(
  x1: number,
  y1: number,
  r1: number,
  x2: number,
  y2: number,
  r2: number
): boolean {
  const dx = x1 - x2;
  const dy = y1 - y2;
  return dx * dx + dy * dy <= (r1 + r2) * (r1 + r2);
}

export function calculateRatingDelta(
  score: number,
  currentRating: number,
  durationSec: number,
  maxCombo: number
): number {
  // Chess.com style progressive rating change
  const performanceExpectation = currentRating * 1.5;
  const performanceActual = score + durationSec * 15 + maxCombo * 40;
  const rawDelta = Math.round((performanceActual - performanceExpectation) / 45);
  // Guarantee reasonable bounds (+5 to +85 on good games, -5 to -25 on early crash)
  if (score > 1000) {
    return Math.max(12, Math.min(65, rawDelta > 0 ? rawDelta : 18));
  }
  return Math.max(-25, Math.min(40, rawDelta));
}

export function getSpeedFactor(mode: "chill" | "neon" | "warp"): number {
  switch (mode) {
    case "chill":
      return 0.8;
    case "warp":
      return 1.4;
    case "neon":
    default:
      return 1.0;
  }
}
