import React, { useEffect, useRef } from "react";
import type { PlayerConfig, PlayerGameState, GameSettings, Obstacle, Orb, Particle, ScorePopup, PlayerId } from "../types/game";
import { checkCircleCollision } from "./rules";
import { sounds } from "../utils/audio";

interface Props {
  settings: GameSettings;
  playerConfigs: Record<PlayerId, PlayerConfig>;
  playerStates: Record<PlayerId, PlayerGameState>;
  onUpdatePlayerStates: (updater: (prev: Record<PlayerId, PlayerGameState>) => Record<PlayerId, PlayerGameState>) => void;
  onGameOver: (winnerId: PlayerId, finalScores: Record<PlayerId, number>) => void;
  isPaused: boolean;
}

export const BallBalanceCanvas: React.FC<Props> = ({
  settings,
  playerConfigs,
  playerStates,
  onUpdatePlayerStates,
  onGameOver,
  isPaused,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(performance.now());

  const hazardsRef = useRef<Obstacle[]>([]);
  const levitationOrbsRef = useRef<Orb[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const scorePopupsRef = useRef<ScorePopup[]>([]);
  const nextHazardTimeRef = useRef<number>(0);
  const nextOrbTimeRef = useRef<number>(0);
  const entityIdCounter = useRef<number>(1);
  const gameDurationRef = useRef<number>(0);

  const activePlayerIds = (Object.keys(playerConfigs) as unknown as PlayerId[])
    .map(Number)
    .filter((id) => id <= settings.playerCount) as PlayerId[];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let isRunning = true;

    const resize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
    };

    resize();
    window.addEventListener("resize", resize);

    const spawnRoofHazard = () => {
      const id = entityIdCounter.current++;
      const x = (Math.random() * 2 - 1) * 0.85;
      const width = 0.24 + Math.random() * 0.16;
      const speed = 0.48 + Math.min(gameDurationRef.current * 0.007, 0.4);
      hazardsRef.current.push({
        id,
        x,
        y: -0.1,
        width,
        height: 0.08,
        speed,
        color: "#F43F5E",
        isCeilingHazard: true,
      });
    };

    const spawnLevitationOrb = () => {
      const id = entityIdCounter.current++;
      const x = (Math.random() * 2 - 1) * 0.8;
      levitationOrbsRef.current.push({
        id,
        x,
        y: -0.1,
        radius: 14,
        pulsePhase: 0,
        value: 120,
      });
    };

    const loop = (now: number) => {
      if (!isRunning) return;
      const dt = Math.min((now - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = now;

      if (!isPaused) {
        gameDurationRef.current += dt;

        // Spawning roof hazards
        if (now > nextHazardTimeRef.current) {
          spawnRoofHazard();
          const interval = Math.max(750, 1600 - gameDurationRef.current * 15);
          nextHazardTimeRef.current = now + interval;
        }

        // Spawning levitation orbs
        if (now > nextOrbTimeRef.current) {
          spawnLevitationOrb();
          nextOrbTimeRef.current = now + 1400 + Math.random() * 800;
        }

        // Move roof hazards down
        for (let i = hazardsRef.current.length - 1; i >= 0; i--) {
          const h = hazardsRef.current[i];
          h.y += h.speed * dt;
          if (h.y > 1.2) {
            hazardsRef.current.splice(i, 1);
          }
        }

        // Move orbs down
        for (let i = levitationOrbsRef.current.length - 1; i >= 0; i--) {
          const orb = levitationOrbsRef.current[i];
          orb.y += 0.4 * dt;
          orb.pulsePhase += dt * 4;
          if (orb.y > 1.2) {
            levitationOrbsRef.current.splice(i, 1);
          }
        }

        // Update particles
        for (let i = particlesRef.current.length - 1; i >= 0; i--) {
          const p = particlesRef.current[i];
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.life += dt;
          p.alpha = Math.max(0, 1 - p.life / p.maxLife);
          if (p.life >= p.maxLife) {
            particlesRef.current.splice(i, 1);
          }
        }

        // Update score popups
        for (let i = scorePopupsRef.current.length - 1; i >= 0; i--) {
          const sp = scorePopupsRef.current[i];
          sp.y -= 26 * dt;
          sp.alpha -= dt * 1.5;
          if (sp.alpha <= 0.05) {
            scorePopupsRef.current.splice(i, 1);
          }
        }

        // Update player jump physics, tilt & collision
        onUpdatePlayerStates((prev) => {
          const next = { ...prev };
          let livingCount = 0;
          let highestScore = -1;
          let leaderId: PlayerId = 1;

          activePlayerIds.forEach((pid) => {
            const p = { ...next[pid] };
            if (!p.alive) return;
            livingCount++;

            // Smooth tilt interpolation
            p.x += (p.targetX - p.x) * 0.22;
            p.x = Math.max(-0.9, Math.min(0.9, p.x));

            // Jump gravity physics
            if (p.isJumping) {
              p.jumpVelocity -= 26 * dt; // gravity pull
              p.jumpHeight += p.jumpVelocity * dt;

              if (p.jumpHeight <= 0) {
                p.jumpHeight = 0;
                p.isJumping = false;
                p.jumpVelocity = 0;
              }
            }

            // Altitude & score climbing
            p.altitude = (p.altitude || 0) + dt * 14;
            p.score += Math.round(dt * 12);

            if (p.score > highestScore) {
              highestScore = p.score;
              leaderId = pid;
            }

            if (p.invulnerableTimer > 0) {
              p.invulnerableTimer = Math.max(0, p.invulnerableTimer - dt);
            }

            // Levitation ambient sparks under ball
            if (Math.random() < 0.6) {
              particlesRef.current.push({
                x: p.x + (Math.random() - 0.5) * 0.03,
                y: 0.82 + (Math.random() - 0.5) * 0.02,
                vx: (Math.random() - 0.5) * 0.04,
                vy: 0.18 + Math.random() * 0.15,
                size: 3,
                alpha: 0.7,
                color: playerConfigs[pid].glowColor,
                life: 0,
                maxLife: 0.5,
              });
            }

            // Collect levitation orbs
            for (let i = levitationOrbsRef.current.length - 1; i >= 0; i--) {
              const orb = levitationOrbsRef.current[i];
              const hit = checkCircleCollision(p.x, 0.8, 0.07, orb.x, orb.y, 0.06);

              if (hit) {
                levitationOrbsRef.current.splice(i, 1);
                sounds.playOrb(p.combo);

                const points = orb.value * p.combo;
                p.score += points;
                p.orbsCollected++;
                p.combo = Math.min(5, p.combo + 1);

                scorePopupsRef.current.push({
                  x: orb.x,
                  y: orb.y,
                  text: `+${points} ORB!`,
                  alpha: 1,
                  color: playerConfigs[pid].color,
                });
              }
            }

            // Collision with roof hazards (CAN BE DODGED BY JUMPING OVER!)
            if (p.invulnerableTimer <= 0) {
              const playerY = 0.8;
              const ballRadius = 0.055;

              for (const hz of hazardsRef.current) {
                // If the player jumped high enough (jumpHeight > 0.35), they LEAP OVER THE ROOF HAZARD!
                const isEvadingViaJump = p.isJumping && p.jumpHeight > 0.35;

                const withinX =
                  Math.abs(p.x - hz.x) < hz.width / 2 + ballRadius;
                const withinY =
                  Math.abs(playerY - hz.y) < hz.height / 2 + ballRadius;

                if (withinX && withinY) {
                  if (isEvadingViaJump) {
                    // Successfully leaped over falling roof hazard!
                    p.score += 75;
                    scorePopupsRef.current.push({
                      x: p.x,
                      y: 0.65,
                      text: "JUMP DODGE! +75",
                      alpha: 1,
                      color: "#34D399",
                    });
                  } else {
                    // Crushed by roof hazard
                    sounds.playCrash();
                    p.lives--;
                    p.invulnerableTimer = 1.6;
                    p.combo = 1;

                    if (p.lives <= 0) {
                      p.alive = false;
                    }
                  }
                  break;
                }
              }
            }

            next[pid] = p;
          });

          if (livingCount === 0 && activePlayerIds.length > 0) {
            const scores: Record<PlayerId, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };
            activePlayerIds.forEach((pid) => (scores[pid] = next[pid].score));
            setTimeout(() => onGameOver(leaderId, scores), 100);
          }

          return next;
        });
      }

      render(ctx, canvas);
      animFrameRef.current = requestAnimationFrame(loop);
    };

    const render = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => {
      const w = canvas.width;
      const h = canvas.height;

      // Dark cosmos background with vertical rising wind streams
      ctx.fillStyle = "#0B0A10";
      ctx.fillRect(0, 0, w, h);

      const numCols = settings.playerCount > 1 ? settings.playerCount : 1;
      const colWidth = w / numCols;

      // Split dividers
      for (let c = 0; c < numCols; c++) {
        const cx = c * colWidth;
        if (c > 0) {
          ctx.strokeStyle = "rgba(196, 181, 253, 0.25)";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(cx, 0);
          ctx.lineTo(cx, h);
          ctx.stroke();
        }

        // Thermal column glows
        const gradient = ctx.createLinearGradient(cx, 0, cx + colWidth, 0);
        gradient.addColorStop(0, "rgba(167, 139, 250, 0.02)");
        gradient.addColorStop(0.5, "rgba(196, 181, 253, 0.06)");
        gradient.addColorStop(1, "rgba(167, 139, 250, 0.02)");
        ctx.fillStyle = gradient;
        ctx.fillRect(cx, 0, colWidth, h);
      }

      // Rising thermal stream lines
      const streamOffset = (gameDurationRef.current * 160) % 40;
      ctx.strokeStyle = "rgba(196, 181, 253, 0.08)";
      ctx.lineWidth = 1;
      for (let y = h - streamOffset; y > 0; y -= 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Draw roof falling hazards (crushers & spikes from top)
      hazardsRef.current.forEach((hz) => {
        const ox = ((hz.x + 1) / 2) * w;
        const oy = hz.y * h;
        const ow = (hz.width / 2) * w;
        const oh = hz.height * h;

        ctx.save();
        ctx.shadowColor = "#F43F5E";
        ctx.shadowBlur = 12;
        ctx.fillStyle = "#E11D48";
        ctx.strokeStyle = "#FDA4AF";
        ctx.lineWidth = 2;

        // Spiked crusher block
        ctx.beginPath();
        ctx.roundRect(ox - ow / 2, oy - oh / 2, ow, oh, 4);
        ctx.fill();
        ctx.stroke();

        // Warning lightning core
        ctx.fillStyle = "#FFF";
        ctx.font = "bold 12px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("⚡ CRUSH", ox, oy + 4);

        ctx.restore();
      });

      // Draw levitation orbs
      levitationOrbsRef.current.forEach((orb) => {
        const ox = ((orb.x + 1) / 2) * w;
        const oy = orb.y * h;
        const rad = orb.radius * (1 + 0.12 * Math.sin(orb.pulsePhase));

        ctx.save();
        ctx.shadowColor = "#38BDF8";
        ctx.shadowBlur = 16;
        ctx.fillStyle = "#BAE6FD";
        ctx.beginPath();
        ctx.arc(ox, oy, rad, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = "rgba(56, 189, 248, 0.6)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(ox, oy, rad * 1.4, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      });

      // Draw particles
      particlesRef.current.forEach((p) => {
        const px = ((p.x + 1) / 2) * w;
        const py = p.y * h;
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(px, py, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw balancing glowing balls
      activePlayerIds.forEach((pid, index) => {
        const p = playerStates[pid];
        const cfg = playerConfigs[pid];
        if (!p) return;

        let px = ((p.x + 1) / 2) * w;
        if (numCols > 1) {
          const colX = index * colWidth;
          px = colX + ((p.x + 1) / 2) * colWidth;
        }

        const baseY = 0.8 * h;
        // Jump elevation offset in pixels
        const jumpOffset = (p.jumpHeight || 0) * 110;
        const py = baseY - jumpOffset;

        if (p.invulnerableTimer > 0 && Math.floor(p.invulnerableTimer * 12) % 2 === 0) {
          return;
        }

        ctx.save();
        if (!p.alive) {
          ctx.globalAlpha = 0.3;
        }

        // Draw shadow on ground (shrinks as ball ascends into jump)
        const shadowScale = Math.max(0.4, 1 - (p.jumpHeight || 0) * 0.8);
        ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
        ctx.beginPath();
        ctx.ellipse(px, baseY + 12, 16 * shadowScale, 6 * shadowScale, 0, 0, Math.PI * 2);
        ctx.fill();

        // Ball glow aura
        ctx.shadowColor = cfg.glowColor;
        ctx.shadowBlur = 18 + (p.isJumping ? 12 : 0);
        ctx.fillStyle = cfg.color;

        // Glowing sphere with 3D gradient highlight
        ctx.beginPath();
        const ballRad = 18 + (p.isJumping ? 4 : 0);
        ctx.arc(px, py, ballRad, 0, Math.PI * 2);
        ctx.fill();

        // Inner specular reflection
        ctx.fillStyle = "#FFFFFF";
        ctx.beginPath();
        ctx.arc(px - ballRad * 0.3, py - ballRad * 0.3, ballRad * 0.35, 0, Math.PI * 2);
        ctx.fill();

        // Player emoji tag
        ctx.font = "14px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(cfg.emoji, px, py - ballRad - 8);

        // Jump state badge if leaping
        if (p.isJumping) {
          ctx.fillStyle = "#34D399";
          ctx.font = "bold 10px monospace";
          ctx.fillText("AIRBORNE!", px, py + ballRad + 14);
        }

        ctx.restore();
      });

      // Score popups
      scorePopupsRef.current.forEach((sp) => {
        const sx = ((sp.x + 1) / 2) * w;
        const sy = sp.y * h;
        ctx.save();
        ctx.globalAlpha = sp.alpha;
        ctx.fillStyle = sp.color;
        ctx.font = "bold 15px 'Inter Tight', system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(sp.text, sx, sy);
        ctx.restore();
      });
    };

    lastTimeRef.current = performance.now();
    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      isRunning = false;
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [settings.playerCount, isPaused, activePlayerIds.length]);

  return (
    <div className="relative w-full h-[540px] md:h-[620px] rounded-2xl overflow-hidden bg-[#0B0A10] border border-cyan-500/20 shadow-2xl">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
