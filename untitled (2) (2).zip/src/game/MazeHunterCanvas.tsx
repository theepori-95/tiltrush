import React, { useEffect, useRef } from "react";
import type { PlayerConfig, PlayerGameState, GameSettings, HunterEnemy, PlayerId, ScorePopup } from "../types/game";
import { sounds } from "../utils/audio";

interface Props {
  settings: GameSettings;
  playerConfigs: Record<PlayerId, PlayerConfig>;
  playerStates: Record<PlayerId, PlayerGameState>;
  onUpdatePlayerStates: (updater: (prev: Record<PlayerId, PlayerGameState>) => Record<PlayerId, PlayerGameState>) => void;
  onGameOver: (winnerId: PlayerId, finalScores: Record<PlayerId, number>) => void;
  isPaused: boolean;
}

// 15x15 Cyber Maze Grid
// 1 = Wall, 0 = Pellet Corridor, 2 = Exit Portal, 3 = Power Key, 4 = Safe Start
const MAZE_TEMPLATE = [
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 4, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 1],
  [1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1],
  [1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1],
  [1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1],
  [1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1],
  [1, 0, 0, 0, 1, 0, 3, 0, 0, 1, 0, 0, 0, 0, 1],
  [1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1],
  [1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1],
  [1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1],
  [1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1],
  [1, 4, 0, 0, 0, 1, 0, 2, 0, 1, 0, 0, 0, 4, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
];

const GRID_SIZE = 15;

export const MazeHunterCanvas: React.FC<Props> = ({
  settings,
  playerConfigs,
  playerStates,
  onUpdatePlayerStates,
  onGameOver,
  isPaused,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(performance.now());

  // Maze dynamic state
  const mazeGridRef = useRef<number[][]>(JSON.parse(JSON.stringify(MAZE_TEMPLATE)));
  const hunterRef = useRef<HunterEnemy>({
    x: 7.5,
    y: 7.5,
    gridCol: 7,
    gridRow: 7,
    targetCol: 7,
    targetRow: 7,
    speed: 1.8,
    aggroTarget: 1,
    color: "#EF4444",
  });
  const hunterStunTimerRef = useRef<number>(0);
  const scorePopupsRef = useRef<ScorePopup[]>([]);
  const gameDurationRef = useRef<number>(0);

  const activePlayerIds = (Object.keys(playerConfigs) as unknown as PlayerId[])
    .map(Number)
    .filter((id) => id <= settings.playerCount) as PlayerId[];

  // Initial spawn positions for players in corners
  const START_POSITIONS: Record<PlayerId, { col: number; row: number }> = {
    1: { col: 1, row: 1 },
    2: { col: 13, row: 1 },
    3: { col: 1, row: 13 },
    4: { col: 13, row: 13 },
  };

  useEffect(() => {
    // Reset maze pellets
    mazeGridRef.current = JSON.parse(JSON.stringify(MAZE_TEMPLATE));
    hunterRef.current = {
      x: 7.5,
      y: 7.5,
      gridCol: 7,
      gridRow: 7,
      targetCol: 7,
      targetRow: 7,
      speed: 1.85,
      aggroTarget: 1,
      color: "#EF4444",
    };
  }, [settings.gameType]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let isRunning = true;

    const resize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
    };

    resize();
    window.addEventListener("resize", resize);

    const isWalkable = (c: number, r: number) => {
      if (c < 0 || c >= GRID_SIZE || r < 0 || r >= GRID_SIZE) return false;
      return mazeGridRef.current[r][c] !== 1;
    };

    const loop = (now: number) => {
      if (!isRunning) return;
      const dt = Math.min((now - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = now;

      if (!isPaused) {
        gameDurationRef.current += dt;

        // Hunter update
        if (hunterStunTimerRef.current > 0) {
          hunterStunTimerRef.current -= dt;
        } else {
          // Hunter AI chases nearest living player
          let closestDist = 999;
          let targetPid: PlayerId = 1;
          let targetPos = { x: 7, y: 7 };

          activePlayerIds.forEach((pid) => {
            const p = playerStates[pid];
            if (p && p.alive && !p.escaped) {
              const dx = (p.gridCol || 1) - hunterRef.current.x;
              const dy = (p.gridRow || 1) - hunterRef.current.y;
              const dist = Math.sqrt(dx * dx + dy * dy);
              if (dist < closestDist) {
                closestDist = dist;
                targetPid = pid;
                targetPos = { x: p.gridCol || 1, y: p.gridRow || 1 };
              }
            }
          });

          hunterRef.current.aggroTarget = targetPid;

          // Simple greedy step towards player along walkable paths
          const h = hunterRef.current;
          const hCol = Math.round(h.x);
          const hRow = Math.round(h.y);

          const possibleMoves = [
            { c: hCol + 1, r: hRow },
            { c: hCol - 1, r: hRow },
            { c: hCol, r: hRow + 1 },
            { c: hCol, r: hRow - 1 },
          ].filter((m) => isWalkable(m.c, m.r));

          let bestMove = possibleMoves[0] || { c: hCol, r: hRow };
          let minD = 999;
          for (const m of possibleMoves) {
            const d = Math.hypot(m.c - targetPos.x, m.r - targetPos.y);
            if (d < minD) {
              minD = d;
              bestMove = m;
            }
          }

          // Move hunter smoothly
          const moveSpeed = h.speed * dt;
          const dirX = bestMove.c - h.x;
          const dirY = bestMove.r - h.y;
          const len = Math.hypot(dirX, dirY) || 1;
          h.x += (dirX / len) * moveSpeed;
          h.y += (dirY / len) * moveSpeed;
        }

        // Update score popups
        for (let i = scorePopupsRef.current.length - 1; i >= 0; i--) {
          const sp = scorePopupsRef.current[i];
          sp.y -= 24 * dt;
          sp.alpha -= dt * 1.5;
          if (sp.alpha <= 0.05) {
            scorePopupsRef.current.splice(i, 1);
          }
        }

        // Update player movements inside maze
        onUpdatePlayerStates((prev) => {
          const next = { ...prev };
          let livingCount = 0;
          let highestScore = -1;
          let leaderId: PlayerId = 1;

          activePlayerIds.forEach((pid) => {
            const p = { ...next[pid] };
            if (!p.alive) return;
            livingCount++;

            // Initialize col/row if needed
            if (p.gridCol === undefined || p.gridCol === 0) {
              const start = START_POSITIONS[pid];
              p.gridCol = start.col;
              p.gridRow = start.row;
            }

            // Direction from tilt input (targetX is -1 to 1, targetY is -1 to 1)
            const steerX = p.targetX || 0;
            const steerY = p.targetY || 0;

            let nextCol = p.gridCol;
            let nextRow = p.gridRow;

            const threshold = 0.35;
            if (Math.abs(steerX) > Math.abs(steerY)) {
              if (steerX > threshold && isWalkable(p.gridCol + 1, p.gridRow)) {
                nextCol = p.gridCol + 1;
              } else if (steerX < -threshold && isWalkable(p.gridCol - 1, p.gridRow)) {
                nextCol = p.gridCol - 1;
              }
            } else {
              if (steerY > threshold && isWalkable(p.gridCol, p.gridRow + 1)) {
                nextRow = p.gridRow + 1;
              } else if (steerY < -threshold && isWalkable(p.gridCol, p.gridRow - 1)) {
                nextRow = p.gridRow - 1;
              }
            }

            p.gridCol = nextCol;
            p.gridRow = nextRow;

            // Check current cell entity in maze
            const cellType = mazeGridRef.current[p.gridRow][p.gridCol];
            if (cellType === 0) {
              // Eat pellet
              mazeGridRef.current[p.gridRow][p.gridCol] = 4; // marked as empty
              p.score += 25;
              p.pelletsEaten = (p.pelletsEaten || 0) + 1;
              sounds.playOrb(1);
            } else if (cellType === 3) {
              // Collected power key!
              mazeGridRef.current[p.gridRow][p.gridCol] = 4;
              p.hasKey = true;
              p.score += 300;
              sounds.playOverdrive();
              scorePopupsRef.current.push({
                x: 0,
                y: 0.5,
                text: "ACCESS KEY UNLOCKED! EXIT OPEN!",
                alpha: 1,
                color: "#FBBF24",
              });
            } else if (cellType === 2) {
              // Reached Exit Portal!
              if (p.hasKey && !p.escaped) {
                p.escaped = true;
                p.score += 1000;
                sounds.playBeep(true);
                scorePopupsRef.current.push({
                  x: 0,
                  y: 0.4,
                  text: `${playerConfigs[pid].name} ESCAPED! +1000`,
                  alpha: 1,
                  color: "#34D399",
                });
              }
            }

            // Check collision with Hunter
            const hDist = Math.hypot(p.gridCol - hunterRef.current.x, p.gridRow - hunterRef.current.y);
            if (hDist < 0.85 && p.invulnerableTimer <= 0 && !p.escaped) {
              // Hunter caught the player!
              sounds.playCrash();
              p.lives--;
              p.invulnerableTimer = 2.0;

              if (p.lives <= 0) {
                p.alive = false;
                scorePopupsRef.current.push({
                  x: 0,
                  y: 0.5,
                  text: `${playerConfigs[pid].name} ELIMINATED BY HUNTER!`,
                  alpha: 1,
                  color: "#EF4444",
                });
              }
            }

            if (p.invulnerableTimer > 0) {
              p.invulnerableTimer = Math.max(0, p.invulnerableTimer - dt);
            }

            if (p.score > highestScore) {
              highestScore = p.score;
              leaderId = pid;
            }

            next[pid] = p;
          });

          // Check if all players escaped or died
          const activeAlive = activePlayerIds.filter((pid) => next[pid].alive && !next[pid].escaped);
          if (activeAlive.length === 0 && activePlayerIds.length > 0) {
            const scores: Record<PlayerId, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };
            activePlayerIds.forEach((pid) => (scores[pid] = next[pid].score));
            setTimeout(() => onGameOver(leaderId, scores), 100);
          }

          return next;
        });
      }

      render(ctx, canvas);
      animFrameRef.current = requestAnimationFrame(loop);
    };

    const render = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => {
      const w = canvas.width;
      const h = canvas.height;

      ctx.fillStyle = "#0B0A10";
      ctx.fillRect(0, 0, w, h);

      // Center the maze grid in canvas
      const side = Math.min(w, h) * 0.94;
      const cellSize = side / GRID_SIZE;
      const startX = (w - side) / 2;
      const startY = (h - side) / 2;

      // Draw maze cells
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const cell = mazeGridRef.current[r][c];
          const x = startX + c * cellSize;
          const y = startY + r * cellSize;

          if (cell === 1) {
            // Cyber wall
            ctx.fillStyle = "#191622";
            ctx.strokeStyle = "rgba(167, 139, 250, 0.4)";
            ctx.lineWidth = 1.5;
            ctx.fillRect(x, y, cellSize, cellSize);
            ctx.strokeRect(x, y, cellSize, cellSize);
          } else {
            // Corridor floor
            ctx.fillStyle = "#100E17";
            ctx.fillRect(x, y, cellSize, cellSize);

            if (cell === 0) {
              // Glowing data pellet
              ctx.fillStyle = "#C4B5FD";
              ctx.beginPath();
              ctx.arc(x + cellSize / 2, y + cellSize / 2, 3, 0, Math.PI * 2);
              ctx.fill();
            } else if (cell === 3) {
              // Access Key
              ctx.save();
              ctx.shadowColor = "#FBBF24";
              ctx.shadowBlur = 10;
              ctx.fillStyle = "#FBBF24";
              ctx.font = `${Math.round(cellSize * 0.7)}px sans-serif`;
              ctx.textAlign = "center";
              ctx.textBaseline = "middle";
              ctx.fillText("🔑", x + cellSize / 2, y + cellSize / 2);
              ctx.restore();
            } else if (cell === 2) {
              // Exit portal
              ctx.save();
              ctx.shadowColor = "#34D399";
              ctx.shadowBlur = 16;
              ctx.strokeStyle = "#34D399";
              ctx.lineWidth = 3;
              ctx.strokeRect(x + 2, y + 2, cellSize - 4, cellSize - 4);
              ctx.fillStyle = "rgba(52, 211, 153, 0.25)";
              ctx.fillRect(x + 2, y + 2, cellSize - 4, cellSize - 4);
              ctx.fillStyle = "#FFF";
              ctx.font = `bold ${Math.round(cellSize * 0.35)}px sans-serif`;
              ctx.textAlign = "center";
              ctx.textBaseline = "middle";
              ctx.fillText("EXIT", x + cellSize / 2, y + cellSize / 2);
              ctx.restore();
            }
          }
        }
      }

      // Draw Cyber Hunter / Nemesis
      const hunter = hunterRef.current;
      const hx = startX + hunter.x * cellSize + cellSize / 2;
      const hy = startY + hunter.y * cellSize + cellSize / 2;

      ctx.save();
      ctx.shadowColor = "#EF4444";
      ctx.shadowBlur = 20;
      ctx.fillStyle = "#DC2626";
      ctx.beginPath();
      ctx.arc(hx, hy, cellSize * 0.42, 0, Math.PI * 2);
      ctx.fill();

      // Pulsing hunter skull / drone icon
      ctx.fillStyle = "#FFFFFF";
      ctx.font = `${Math.round(cellSize * 0.55)}px sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("💀", hx, hy);

      // Warning target line to aggro player
      const aggroPlayer = playerStates[hunter.aggroTarget];
      if (aggroPlayer && aggroPlayer.alive && !aggroPlayer.escaped) {
        const px = startX + (aggroPlayer.gridCol || 1) * cellSize + cellSize / 2;
        const py = startY + (aggroPlayer.gridRow || 1) * cellSize + cellSize / 2;
        ctx.strokeStyle = "rgba(239, 68, 68, 0.25)";
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(hx, hy);
        ctx.lineTo(px, py);
        ctx.stroke();
      }
      ctx.restore();

      // Draw all active players
      activePlayerIds.forEach((pid) => {
        const p = playerStates[pid];
        const cfg = playerConfigs[pid];
        if (!p) return;

        const px = startX + (p.gridCol || 1) * cellSize + cellSize / 2;
        const py = startY + (p.gridRow || 1) * cellSize + cellSize / 2;

        if (p.invulnerableTimer > 0 && Math.floor(p.invulnerableTimer * 10) % 2 === 0) {
          return;
        }

        ctx.save();
        if (!p.alive) {
          ctx.globalAlpha = 0.3;
        }

        ctx.shadowColor = cfg.glowColor;
        ctx.shadowBlur = 14;
        ctx.fillStyle = cfg.color;
        ctx.beginPath();
        ctx.arc(px, py, cellSize * 0.38, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#FFF";
        ctx.font = `${Math.round(cellSize * 0.5)}px sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(cfg.emoji, px, py);

        ctx.restore();
      });

      // Score Popups
      scorePopupsRef.current.forEach((sp) => {
        const sx = w / 2;
        const sy = sp.y * h;
        ctx.save();
        ctx.globalAlpha = sp.alpha;
        ctx.fillStyle = sp.color;
        ctx.font = "bold 18px 'Inter Tight', system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(sp.text, sx, sy);
        ctx.restore();
      });
    };

    lastTimeRef.current = performance.now();
    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      isRunning = false;
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [settings.gameType, settings.playerCount, isPaused, activePlayerIds.length]);

  return (
    <div className="relative w-full h-[540px] md:h-[620px] rounded-2xl overflow-hidden bg-[#0B0A10] border border-rose-500/20 shadow-2xl flex items-center justify-center">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
