import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import type { PlayerConfig, PlayerGameState, GameSettings, PlayerId } from "../types/game";
import { sounds } from "../utils/audio";
import { Play, Pause, RotateCcw, Volume2, VolumeX, ChevronDown, ChevronUp, Zap, Heart, Trophy } from "lucide-react";

interface Props {
  settings: GameSettings;
  playerConfigs: Record<PlayerId, PlayerConfig>;
  playerStates: Record<PlayerId, PlayerGameState>;
  onUpdatePlayerStates: (updater: (prev: Record<PlayerId, PlayerGameState>) => Record<PlayerId, PlayerGameState>) => void;
  onGameOver: (winnerId: PlayerId, finalScores: Record<PlayerId, number>) => void;
  roomCode: string;
}

type GameShellState = "title" | "playing" | "paused" | "gameover";

export const ThreeNeonArena: React.FC<Props> = ({
  settings,
  playerConfigs,
  playerStates,
  onUpdatePlayerStates,
  onGameOver,
  roomCode,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [shellState, setShellState] = useState<GameShellState>("title");
  const [hudCollapsed, setHudCollapsed] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const [scoreDisplay, setScoreDisplay] = useState(0);
  const [livesDisplay, setLivesDisplay] = useState(3);
  const [comboDisplay, setComboDisplay] = useState(1);
  const [winnerName, setWinnerName] = useState("");

  const stateRef = useRef({
    shellState: "title" as GameShellState,
    score: 0,
    lives: 3,
    combo: 1,
    hitstopTimer: 0,
    shakeIntensity: 0,
    shipX: 0,
    targetX: 0,
    speed: 35,
    altitude: 0,
    isJumping: false,
    jumpVelocity: 0,
    jumpHeight: 0,
    overdriveTimer: 0,
  });

  stateRef.current.shellState = shellState;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // SCENE SETUP
    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#0B0A10");
    scene.fog = new THREE.FogExp2("#0B0A10", 0.016);

    // CAMERA
    const camera = new THREE.PerspectiveCamera(58, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 5, 12);

    // RENDERER with PBR Standards
    const isHeadless = navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent);
    const renderer = new THREE.WebGLRenderer({ antialias: !isHeadless, powerPreference: "high-performance" });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(isHeadless ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isHeadless;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // STUDIO PBR ENVIRONMENT
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 3-POINT STUDIO LIGHTING RIG
    const keyLight = new THREE.DirectionalLight("#FFF8E7", 2.2);
    keyLight.position.set(8, 16, 10);
    keyLight.castShadow = !isHeadless;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight("#C4B5FD", "#0B0A10", 0.85);
    scene.add(hemiLight);

    const rimLight = new THREE.PointLight("#A78BFA", 1.8, 40);
    rimLight.position.set(-6, 8, -10);
    scene.add(rimLight);

    // PROCEDURAL TRACK / GROUND TEXTURE
    const canvasTex = document.createElement("canvas");
    canvasTex.width = 512;
    canvasTex.height = 512;
    const ctx = canvasTex.getContext("2d")!;
    ctx.fillStyle = "#0D0B14";
    ctx.fillRect(0, 0, 512, 512);
    ctx.strokeStyle = "rgba(196, 181, 253, 0.15)";
    ctx.lineWidth = 2;
    for (let x = 0; x <= 512; x += 64) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 512);
      ctx.stroke();
    }
    for (let y = 0; y <= 512; y += 64) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(512, y);
      ctx.stroke();
    }
    // Neon speed center stripes
    ctx.fillStyle = "#A78BFA";
    ctx.fillRect(250, 0, 12, 512);

    const groundTexture = new THREE.CanvasTexture(canvasTex);
    groundTexture.wrapS = THREE.RepeatWrapping;
    groundTexture.wrapT = THREE.RepeatWrapping;
    groundTexture.repeat.set(8, 40);
    groundTexture.colorSpace = THREE.SRGBColorSpace;
    groundTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    const groundMat = new THREE.MeshStandardMaterial({
      map: groundTexture,
      roughness: 0.8,
      metalness: 0.2,
    });
    const groundGeo = new THREE.PlaneGeometry(36, 400);
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.receiveShadow = !isHeadless;
    scene.add(groundMesh);

    // COMPOSITE 7-PART PROCEDURAL HOVERCRAFT (THREE.Group)
    const hovercraftGroup = new THREE.Group();

    // 1. Primary Hull Chassis (Aerodynamic wedge)
    const hullShape = new THREE.Shape();
    hullShape.moveTo(0, 2.2);
    hullShape.lineTo(1.4, -1.2);
    hullShape.lineTo(0.5, -1.6);
    hullShape.lineTo(0, -1.4);
    hullShape.lineTo(-0.5, -1.6);
    hullShape.lineTo(-1.4, -1.2);
    hullShape.closePath();

    const extrudeSettings = { depth: 0.45, bevelEnabled: true, bevelSegments: 3, steps: 1, bevelSize: 0.08, bevelThickness: 0.08 };
    const hullGeo = new THREE.ExtrudeGeometry(hullShape, extrudeSettings);
    hullGeo.center();
    const hullMat = new THREE.MeshStandardMaterial({
      color: "#C4B5FD",
      metalness: 0.85,
      roughness: 0.2,
    });
    const hullMesh = new THREE.Mesh(hullGeo, hullMat);
    hullMesh.rotation.x = -Math.PI / 2;
    hullMesh.castShadow = !isHeadless;
    hovercraftGroup.add(hullMesh);

    // 2. Cockpit Canopy Glass Bubble
    const canopyGeo = new THREE.SphereGeometry(0.55, 24, 16);
    canopyGeo.scale(0.8, 0.45, 1.8);
    const canopyMat = new THREE.MeshPhysicalMaterial({
      color: "#0B0A10",
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.92,
      thickness: 1.2,
      clearcoat: 1.0,
      ior: 1.52,
    });
    const canopyMesh = new THREE.Mesh(canopyGeo, canopyMat);
    canopyMesh.position.set(0, 0.35, 0.1);
    hovercraftGroup.add(canopyMesh);

    // 3. Dual Swept Aerodynamic Wings
    const wingGeo = new THREE.BoxGeometry(3.6, 0.08, 1.1);
    const wingMat = new THREE.MeshStandardMaterial({
      color: "#A78BFA",
      metalness: 0.75,
      roughness: 0.35,
    });
    const wingMesh = new THREE.Mesh(wingGeo, wingMat);
    wingMesh.position.set(0, 0.05, -0.4);
    hovercraftGroup.add(wingMesh);

    // 4. Twin Plasma Thruster Exhausts
    const thrusterGeo = new THREE.CylinderGeometry(0.24, 0.32, 0.8, 16);
    const thrusterMat = new THREE.MeshStandardMaterial({
      color: "#191622",
      metalness: 0.9,
      roughness: 0.15,
    });
    const leftThruster = new THREE.Mesh(thrusterGeo, thrusterMat);
    leftThruster.rotation.x = Math.PI / 2;
    leftThruster.position.set(-0.7, 0.1, -1.6);
    hovercraftGroup.add(leftThruster);

    const rightThruster = leftThruster.clone();
    rightThruster.position.set(0.7, 0.1, -1.6);
    hovercraftGroup.add(rightThruster);

    // 5. Plasma Thruster Nozzle Glow Core
    const nozzleGlowGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.1, 16);
    const nozzleGlowMat = new THREE.MeshBasicMaterial({ color: "#E879F9" });
    const leftGlow = new THREE.Mesh(nozzleGlowGeo, nozzleGlowMat);
    leftGlow.rotation.x = Math.PI / 2;
    leftGlow.position.set(-0.7, 0.1, -2.0);
    hovercraftGroup.add(leftGlow);

    const rightGlow = leftGlow.clone();
    rightGlow.position.set(0.7, 0.1, -2.0);
    hovercraftGroup.add(rightGlow);

    // 6. Anti-Grav Repulsor Torus Coils
    const repulsorGeo = new THREE.TorusGeometry(0.35, 0.06, 12, 24);
    const repulsorMat = new THREE.MeshStandardMaterial({
      color: "#C4B5FD",
      emissive: "#A78BFA",
      emissiveIntensity: 0.4,
      metalness: 0.6,
      roughness: 0.3,
    });
    const leftRepulsor = new THREE.Mesh(repulsorGeo, repulsorMat);
    leftRepulsor.rotation.x = Math.PI / 2;
    leftRepulsor.position.set(-1.1, -0.15, 0.2);
    hovercraftGroup.add(leftRepulsor);

    const rightRepulsor = leftRepulsor.clone();
    rightRepulsor.position.set(1.1, -0.15, 0.2);
    hovercraftGroup.add(rightRepulsor);

    // 7. Soft Radial Ground Contact Shadow Plane
    const shadowGeo = new THREE.PlaneGeometry(3.5, 4.2);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: "#000000",
      transparent: true,
      opacity: 0.48,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.03;
    hovercraftGroup.add(shadowMesh);

    hovercraftGroup.position.set(0, 0.9, 4);
    scene.add(hovercraftGroup);

    // PROCEDURAL 3D OBSTACLES (Cyber Monoliths)
    const obstacleCount = 14;
    const obstacles: { mesh: THREE.Mesh; z: number; x: number; active: boolean }[] = [];
    const obsGeo = new THREE.BoxGeometry(2.4, 3.2, 1.2);
    const obsMat = new THREE.MeshStandardMaterial({
      color: "#1E1B2E",
      emissive: "#EF4444",
      emissiveIntensity: 0.35,
      metalness: 0.8,
      roughness: 0.25,
    });

    for (let i = 0; i < obstacleCount; i++) {
      const mesh = new THREE.Mesh(obsGeo, obsMat);
      mesh.castShadow = !isHeadless;
      mesh.receiveShadow = !isHeadless;
      const x = (Math.random() - 0.5) * 16;
      const z = -20 - i * 26;
      mesh.position.set(x, 1.6, z);
      scene.add(mesh);
      obstacles.push({ mesh, z, x, active: true });
    }

    // PROCEDURAL 3D COLLECTIBLE PULSE ORBS
    const orbCount = 10;
    const pulseOrbs: { group: THREE.Group; z: number; x: number; active: boolean }[] = [];
    const orbCoreGeo = new THREE.IcosahedronGeometry(0.45, 2);
    const orbCoreMat = new THREE.MeshStandardMaterial({
      color: "#F5D0FE",
      emissive: "#C4B5FD",
      emissiveIntensity: 0.7,
      metalness: 0.4,
      roughness: 0.1,
    });
    const orbRingGeo = new THREE.TorusGeometry(0.7, 0.04, 12, 32);
    const orbRingMat = new THREE.MeshBasicMaterial({ color: "#A78BFA" });

    for (let i = 0; i < orbCount; i++) {
      const grp = new THREE.Group();
      const core = new THREE.Mesh(orbCoreGeo, orbCoreMat);
      const ring = new THREE.Mesh(orbRingGeo, orbRingMat);
      grp.add(core);
      grp.add(ring);

      const x = (Math.random() - 0.5) * 14;
      const z = -15 - i * 32;
      grp.position.set(x, 1.2, z);
      scene.add(grp);
      pulseOrbs.push({ group: grp, z, x, active: true });
    }

    // EXHAUST PARTICLE SYSTEM (InstancedMesh)
    const particleMax = 80;
    const partGeo = new THREE.SphereGeometry(0.08, 8, 8);
    const partMat = new THREE.MeshBasicMaterial({ color: "#C4B5FD", transparent: true, opacity: 0.75 });
    const particles = new THREE.InstancedMesh(partGeo, partMat, particleMax);
    particles.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    scene.add(particles);

    const dummy = new THREE.Object3D();
    const particleData = Array.from({ length: particleMax }, () => ({
      x: 0,
      y: 0,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      life: 0,
      maxLife: 0.6,
    }));

    // KEYBOARD LISTENER
    const keys = { left: false, right: false, up: false, down: false, space: false };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === "ArrowLeft" || e.code === "KeyA") keys.left = true;
      if (e.code === "ArrowRight" || e.code === "KeyD") keys.right = true;
      if (e.code === "ArrowUp" || e.code === "KeyW") keys.up = true;
      if (e.code === "ArrowDown" || e.code === "KeyS") keys.down = true;
      if (e.code === "Space") {
        keys.space = true;
        // Jump / Action trigger
        if (!stateRef.current.isJumping) {
          stateRef.current.isJumping = true;
          stateRef.current.jumpVelocity = 14;
          sounds.playBeep(true);
        }
      }
      if (e.code === "Escape") {
        setShellState((prev) => (prev === "playing" ? "paused" : prev === "paused" ? "playing" : prev));
      }
      if (stateRef.current.shellState === "title" && (e.code === "Enter" || e.code === "Space")) {
        startGame();
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === "ArrowLeft" || e.code === "KeyA") keys.left = false;
      if (e.code === "ArrowRight" || e.code === "KeyD") keys.right = false;
      if (e.code === "ArrowUp" || e.code === "KeyW") keys.up = false;
      if (e.code === "ArrowDown" || e.code === "KeyS") keys.down = false;
      if (e.code === "Space") keys.space = false;
    };
    const onBlur = () => {
      keys.left = false;
      keys.right = false;
      keys.up = false;
      keys.down = false;
      keys.space = false;
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);

    // RESIZE LISTENER
    const onResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener("resize", onResize);

    // CLOCKED ANIMATION LOOP
    const clock = new THREE.Clock();
    let animId = 0;
    let trackOffset = 0;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const rawDt = clock.getDelta();
      const dt = Math.min(rawDt, 0.05); // Frame delta clamped

      // Hitstop logic
      if (stateRef.current.hitstopTimer > 0) {
        stateRef.current.hitstopTimer -= dt;
        return;
      }

      if (stateRef.current.shellState === "title") {
        // Atmospheric live camera pan on Title Screen
        const time = clock.getElapsedTime();
        camera.position.x = Math.sin(time * 0.4) * 4;
        camera.position.y = 5.5 + Math.cos(time * 0.5) * 1.2;
        camera.position.z = 12 + Math.sin(time * 0.3) * 2;
        camera.lookAt(0, 1.2, 0);

        // Hovercraft floating idle
        hovercraftGroup.position.y = 1.0 + Math.sin(time * 2.2) * 0.15;
        hovercraftGroup.rotation.z = Math.sin(time * 1.5) * 0.08;
      } else if (stateRef.current.shellState === "playing") {
        // Active gameplay
        stateRef.current.score += Math.round(dt * 20);

        // Continuous keyboard & phone tilt blend
        let inputDir = 0;
        if (keys.left) inputDir -= 1;
        if (keys.right) inputDir += 1;

        // Merge real phone tilt roll if available from playerStates[1]
        const phoneTilt = playerStates[1]?.targetX || 0;
        if (Math.abs(phoneTilt) > 0.05) {
          inputDir = phoneTilt;
        }

        // Steer physics
        const steerSpeed = 16;
        stateRef.current.shipX += inputDir * steerSpeed * dt;
        stateRef.current.shipX = Math.max(-8, Math.min(8, stateRef.current.shipX));

        // Jump physics
        if (stateRef.current.isJumping) {
          stateRef.current.jumpVelocity -= 32 * dt; // gravity
          stateRef.current.jumpHeight += stateRef.current.jumpVelocity * dt;
          if (stateRef.current.jumpHeight <= 0) {
            stateRef.current.jumpHeight = 0;
            stateRef.current.isJumping = false;
            stateRef.current.jumpVelocity = 0;
          }
        }

        // Smooth bank roll & position
        const targetRoll = -inputDir * 0.35;
        hovercraftGroup.rotation.z = THREE.MathUtils.damp(hovercraftGroup.rotation.z, targetRoll, 8, dt);
        hovercraftGroup.position.x = THREE.MathUtils.damp(hovercraftGroup.position.x, stateRef.current.shipX, 10, dt);
        hovercraftGroup.position.y = 0.9 + stateRef.current.jumpHeight;

        // Ground track scroll
        trackOffset -= stateRef.current.speed * dt * 0.02;
        groundTexture.offset.y = trackOffset;

        // Move obstacles
        obstacles.forEach((obs) => {
          obs.z += stateRef.current.speed * dt;
          if (obs.z > 14) {
            obs.z = -180 - Math.random() * 40;
            obs.x = (Math.random() - 0.5) * 16;
            obs.active = true;
          }
          obs.mesh.position.set(obs.x, 1.6, obs.z);

          // Collision detection
          if (obs.active && Math.abs(obs.z - hovercraftGroup.position.z) < 1.6) {
            const hitX = Math.abs(obs.x - hovercraftGroup.position.x) < 1.8;
            const hitY = stateRef.current.jumpHeight < 1.4; // Jump clears obstacle!

            if (hitX && hitY) {
              obs.active = false;
              sounds.playCrash();

              // Trigger 60ms simulation hitstop + camera shake
              stateRef.current.hitstopTimer = 0.06;
              stateRef.current.shakeIntensity = 0.45;
              stateRef.current.lives--;
              setLivesDisplay(stateRef.current.lives);

              if (stateRef.current.lives <= 0) {
                stateRef.current.shellState = "gameover";
                setShellState("gameover");
                setWinnerName(playerConfigs[1].name);
                onGameOver(1, { 1: stateRef.current.score, 2: 0, 3: 0, 4: 0 });
              }
            }
          }
        });

        // Move pulse orbs
        pulseOrbs.forEach((orb) => {
          orb.z += stateRef.current.speed * dt;
          orb.group.rotation.y += dt * 3;
          if (orb.z > 14) {
            orb.z = -160 - Math.random() * 50;
            orb.x = (Math.random() - 0.5) * 14;
            orb.active = true;
          }
          orb.group.position.set(orb.x, 1.2, orb.z);

          // Orb collection
          if (orb.active && Math.abs(orb.z - hovercraftGroup.position.z) < 1.5) {
            if (Math.abs(orb.x - hovercraftGroup.position.x) < 1.6) {
              orb.active = false;
              orb.group.position.y = -10;
              sounds.playOrb(stateRef.current.combo);

              stateRef.current.score += 150 * stateRef.current.combo;
              stateRef.current.combo = Math.min(5, stateRef.current.combo + 1);
              setScoreDisplay(stateRef.current.score);
              setComboDisplay(stateRef.current.combo);
            }
          }
        });

        // Camera follow with exponential damping
        const targetCamX = hovercraftGroup.position.x * 0.65;
        const targetCamY = 5.2 + hovercraftGroup.position.y * 0.5;
        camera.position.x = THREE.MathUtils.damp(camera.position.x, targetCamX, 6, dt);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, targetCamY, 6, dt);
        camera.position.z = 12;

        // Apply camera shake if any
        if (stateRef.current.shakeIntensity > 0) {
          camera.position.x += (Math.random() - 0.5) * stateRef.current.shakeIntensity;
          camera.position.y += (Math.random() - 0.5) * stateRef.current.shakeIntensity;
          stateRef.current.shakeIntensity = Math.max(0, stateRef.current.shakeIntensity - dt * 2);
        }

        camera.lookAt(hovercraftGroup.position.x * 0.3, 1.4, -6);
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      window.removeEventListener("resize", onResize);

      // Clean disposal
      renderer.dispose();
      groundMat.dispose();
      groundGeo.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  const startGame = () => {
    stateRef.current.score = 0;
    stateRef.current.lives = 3;
    stateRef.current.combo = 1;
    stateRef.current.shipX = 0;
    stateRef.current.jumpHeight = 0;
    stateRef.current.isJumping = false;
    setScoreDisplay(0);
    setLivesDisplay(3);
    setComboDisplay(1);
    setShellState("playing");
    sounds.playBeep(true);
  };

  return (
    <div className="relative w-full h-[640px] md:h-[720px] rounded-3xl overflow-hidden bg-[#0B0A10] border border-purple-500/25 shadow-2xl">
      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="w-full h-full block" />

      {/* Low-Occlusion UI Shell Overlay */}
      {shellState === "playing" && (
        <div className="absolute inset-0 pointer-events-none p-6 flex flex-col justify-between">
          {/* Perimeter Top Status Cluster (Low Occlusion, Tabular-Nums) */}
          <div className="flex items-center justify-between">
            <div className="bg-[#12101A]/85 border border-purple-500/30 px-4 py-2 rounded-2xl flex items-center gap-4 text-xs font-mono shadow-xl">
              <div>
                <span className="text-gray-400">SCORE:</span>{" "}
                <span className="text-lg font-bold text-amber-300 tabular-nums">{scoreDisplay.toLocaleString()}</span>
              </div>
              <div className="border-l border-purple-500/20 pl-4 flex items-center gap-1.5 text-rose-500">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Heart key={i} className={`w-4 h-4 ${i < livesDisplay ? "fill-rose-500" : "text-gray-700"}`} />
                ))}
              </div>
              <div className="border-l border-purple-500/20 pl-4 text-purple-300">
                <span className="font-bold">{comboDisplay}x</span> COMBO
              </div>
            </div>

            <div className="bg-[#12101A]/85 border border-purple-500/30 px-3 py-1.5 rounded-xl text-xs font-mono text-purple-300 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>ROOM: {roomCode}</span>
            </div>
          </div>

          {/* Compact Collapsible Bottom Control Dock (<= 15% footprint) */}
          <div className="pointer-events-auto self-center flex flex-col items-center">
            <button
              onClick={() => setHudCollapsed(!hudCollapsed)}
              className="px-3 py-1 bg-[#12101A]/90 hover:bg-purple-900/40 border border-purple-500/30 rounded-t-xl text-[10px] font-mono text-purple-300 flex items-center gap-1 transition-all"
            >
              {hudCollapsed ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              {hudCollapsed ? "SHOW DOCK" : "HIDE DOCK (ZEN)"}
            </button>

            {!hudCollapsed && (
              <div className="bg-[#12101A]/90 border border-purple-500/30 px-5 py-2.5 rounded-2xl flex items-center gap-4 text-xs shadow-2xl">
                <button
                  onClick={() => setShellState("paused")}
                  className="px-3 py-1 rounded-lg bg-[#191622] hover:bg-purple-900/40 text-purple-200 border border-purple-500/20 font-mono text-[11px] flex items-center gap-1"
                >
                  <Pause className="w-3 h-3" /> Pause (Esc)
                </button>
                <button
                  onClick={() => setSoundOn(!soundOn)}
                  className="px-3 py-1 rounded-lg bg-[#191622] hover:bg-purple-900/40 text-purple-200 border border-purple-500/20 font-mono text-[11px] flex items-center gap-1"
                >
                  {soundOn ? <Volume2 className="w-3 h-3 text-purple-400" /> : <VolumeX className="w-3 h-3" />}
                  {soundOn ? "Audio ON" : "Muted"}
                </button>
                <div className="text-[11px] font-mono text-gray-400 border-l border-purple-500/20 pl-4">
                  WASD / ← → Steer · Space Jump
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Atmospheric Title Screen */}
      {shellState === "title" && (
        <div className="absolute inset-0 bg-[#0B0A10]/55 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center space-y-6">
          {/* Bespoke Inline SVG Title Lockup */}
          <div className="space-y-2 max-w-lg">
            <svg viewBox="0 0 420 80" className="w-full h-auto drop-shadow-[0_0_20px_rgba(196,181,253,0.5)]">
              <defs>
                <linearGradient id="titleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="50%" stopColor="#C4B5FD" />
                  <stop offset="100%" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <text x="50%" y="55" textAnchor="middle" fill="url(#titleGrad)" fontFamily="'Inter Tight', sans-serif" fontWeight="900" fontSize="52" letterSpacing="4">
                TILTRUSH 3D
              </text>
            </svg>
            <div className="text-xs uppercase tracking-[0.25em] font-mono font-bold text-purple-300">
              Three.js PBR Studio Engine · Neon Escape
            </div>
          </div>

          <p className="text-sm text-gray-300 max-w-md leading-relaxed">
            Tilt your real mobile smartphone or pilot with keyboard keys. Avoid cyber monoliths, collect pulse orbs, and balance your reflexes.
          </p>

          <div className="space-y-3 pt-2">
            <button
              onClick={startGame}
              className="py-3.5 px-9 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-extrabold text-sm shadow-xl shadow-purple-500/30 flex items-center justify-center gap-2.5 mx-auto transition-transform hover:scale-105 active:scale-95"
            >
              <Play className="w-4 h-4 fill-white" />
              START 3D ARENA RUN (SPACE / ENTER)
            </button>
            <div className="text-[11px] font-mono text-gray-400">
              WASD Move · Space Jump · Esc Pause
            </div>
          </div>
        </div>
      )}

      {/* Pause Screen Modal */}
      {shellState === "paused" && (
        <div className="absolute inset-0 bg-[#0B0A10]/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center space-y-5">
          <div className="p-3 bg-purple-500/10 rounded-2xl border border-purple-500/30 text-purple-300">
            <Pause className="w-8 h-8" />
          </div>
          <h3 className="text-2xl font-bold text-white tracking-wide">ARENA PAUSED</h3>
          <div className="flex gap-3">
            <button
              onClick={() => setShellState("playing")}
              className="py-2.5 px-6 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs"
            >
              Resume Match
            </button>
            <button
              onClick={startGame}
              className="py-2.5 px-6 rounded-xl bg-[#191622] hover:bg-purple-900/30 text-purple-200 border border-purple-500/30 font-bold text-xs"
            >
              Restart
            </button>
          </div>
        </div>
      )}

      {/* Game Over Modal */}
      {shellState === "gameover" && (
        <div className="absolute inset-0 bg-[#0B0A10]/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center space-y-5 animate-in fade-in zoom-in-95">
          <div className="p-4 bg-amber-500/15 rounded-full text-amber-400 border border-amber-500/30">
            <Trophy className="w-10 h-10" />
          </div>
          <div>
            <div className="text-xs uppercase font-mono tracking-widest text-purple-300">3D Simulation Concluded</div>
            <h3 className="text-3xl font-extrabold text-white mt-1">Final Score: {stateRef.current.score.toLocaleString()}</h3>
          </div>
          <button
            onClick={startGame}
            className="py-3 px-8 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold text-sm shadow-xl flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" /> PLAY AGAIN
          </button>
        </div>
      )}
    </div>
  );
};
