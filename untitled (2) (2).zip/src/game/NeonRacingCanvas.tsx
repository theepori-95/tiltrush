import React, { useEffect, useRef } from "react";
import type { PlayerConfig, PlayerGameState, GameSettings, Obstacle, Orb, Particle, Ripple, ScorePopup, PlayerId } from "../types/game";
import { checkAABBCollision, checkCircleCollision } from "./rules";
import { sounds } from "../utils/audio";

interface Props {
  settings: GameSettings;
  playerConfigs: Record<PlayerId, PlayerConfig>;
  playerStates: Record<PlayerId, PlayerGameState>;
  onUpdatePlayerStates: (updater: (prev: Record<PlayerId, PlayerGameState>) => Record<PlayerId, PlayerGameState>) => void;
  onGameOver: (winnerId: PlayerId, finalScores: Record<PlayerId, number>) => void;
  isPaused: boolean;
  onAddScorePopup?: (text: string, color: string) => void;
}

export const NeonRacingCanvas: React.FC<Props> = ({
  settings,
  playerConfigs,
  playerStates,
  onUpdatePlayerStates,
  onGameOver,
  isPaused,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(performance.now());

  // Game internal entities
  const obstaclesRef = useRef<Obstacle[]>([]);
  const orbsRef = useRef<Orb[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const ripplesRef = useRef<Ripple[]>([]);
  const scorePopupsRef = useRef<ScorePopup[]>([]);
  const nextSpawnTimeRef = useRef<number>(0);
  const nextOrbSpawnTimeRef = useRef<number>(0);
  const entityIdCounter = useRef<number>(1);
  const gameDurationRef = useRef<number>(0);

  const activePlayerIds = (Object.keys(playerConfigs) as unknown as PlayerId[])
    .map(Number)
    .filter((id) => id <= settings.playerCount) as PlayerId[];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let isRunning = true;

    const resize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
    };

    resize();
    window.addEventListener("resize", resize);

    const spawnObstacle = () => {
      const id = entityIdCounter.current++;
      const laneWidth = 0.32;
      const x = (Math.random() * 2 - 1) * (1 - laneWidth * 0.7);
      const width = 0.22 + Math.random() * 0.14;
      const speed = 0.55 + Math.min(gameDurationRef.current * 0.008, 0.45);
      obstaclesRef.current.push({
        id,
        x,
        y: -0.15,
        width,
        height: 0.05,
        speed,
        color: "#EF4444",
      });
    };

    const spawnOrb = () => {
      const id = entityIdCounter.current++;
      const x = (Math.random() * 1.6 - 0.8);
      orbsRef.current.push({
        id,
        x,
        y: -0.1,
        radius: 12,
        pulsePhase: 0,
        value: 100,
      });
    };

    const loop = (now: number) => {
      if (!isRunning) return;
      const dt = Math.min((now - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = now;

      if (!isPaused) {
        gameDurationRef.current += dt;

        // Spawning logic
        if (now > nextSpawnTimeRef.current) {
          spawnObstacle();
          const interval = Math.max(700, 1500 - gameDurationRef.current * 18);
          nextSpawnTimeRef.current = now + interval;
        }

        if (now > nextOrbSpawnTimeRef.current) {
          spawnOrb();
          nextOrbSpawnTimeRef.current = now + 1200 + Math.random() * 900;
        }

        // Move obstacles
        for (let i = obstaclesRef.current.length - 1; i >= 0; i--) {
          const obs = obstaclesRef.current[i];
          obs.y += obs.speed * dt;
          if (obs.y > 1.2) {
            obstaclesRef.current.splice(i, 1);
          }
        }

        // Move orbs
        for (let i = orbsRef.current.length - 1; i >= 0; i--) {
          const orb = orbsRef.current[i];
          orb.y += 0.45 * dt;
          orb.pulsePhase += dt * 5;
          if (orb.y > 1.2) {
            orbsRef.current.splice(i, 1);
          }
        }

        // Update particles
        for (let i = particlesRef.current.length - 1; i >= 0; i--) {
          const p = particlesRef.current[i];
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.life += dt;
          p.alpha = Math.max(0, 1 - p.life / p.maxLife);
          if (p.life >= p.maxLife) {
            particlesRef.current.splice(i, 1);
          }
        }

        // Update ripples
        for (let i = ripplesRef.current.length - 1; i >= 0; i--) {
          const r = ripplesRef.current[i];
          r.radius += (r.maxRadius - r.radius) * 6 * dt;
          r.alpha = Math.max(0, r.alpha - dt * 2.2);
          if (r.alpha <= 0.02) {
            ripplesRef.current.splice(i, 1);
          }
        }

        // Update score popups
        for (let i = scorePopupsRef.current.length - 1; i >= 0; i--) {
          const sp = scorePopupsRef.current[i];
          sp.y -= 28 * dt;
          sp.alpha -= dt * 1.5;
          if (sp.alpha <= 0.05) {
            scorePopupsRef.current.splice(i, 1);
          }
        }

        // Update players state & collisions
        onUpdatePlayerStates((prev) => {
          const next = { ...prev };
          let livingCount = 0;
          let highestScore = -1;
          let leaderId: PlayerId = 1;

          activePlayerIds.forEach((pid) => {
            const p = { ...next[pid] };
            if (!p.alive) return;
            livingCount++;

            // Smooth position interpolation
            const smoothing = 0.22;
            p.x += (p.targetX - p.x) * smoothing;
            p.x = Math.max(-0.92, Math.min(0.92, p.x));

            // Overdrive countdown
            if (p.isOverdrive) {
              p.overdriveTimer -= dt;
              p.score += Math.round(dt * 30);
              if (p.overdriveTimer <= 0) {
                p.isOverdrive = false;
                p.overdriveCapacitor = 0;
              }
            } else {
              p.score += Math.round(dt * 10);
            }

            if (p.score > highestScore) {
              highestScore = p.score;
              leaderId = pid;
            }

            // Invulnerability countdown
            if (p.invulnerableTimer > 0) {
              p.invulnerableTimer = Math.max(0, p.invulnerableTimer - dt);
            }

            // Combo timer decay
            if (p.comboTimer > 0) {
              p.comboTimer -= dt;
              if (p.comboTimer <= 0) {
                p.combo = 1;
              }
            }

            // Exhaust particles (Tilt-to-Flow)
            if (Math.random() < 0.85) {
              const cfg = playerConfigs[pid];
              const pCount = p.isOverdrive ? 4 : 2;
              for (let k = 0; k < pCount; k++) {
                particlesRef.current.push({
                  x: p.x + (Math.random() - 0.5) * 0.04,
                  y: 0.85 + (Math.random() - 0.5) * 0.03,
                  vx: (Math.random() - 0.5) * 0.08,
                  vy: 0.25 + Math.random() * 0.25,
                  size: p.isOverdrive ? 5 : 3.5,
                  alpha: 0.75,
                  color: p.isOverdrive ? "#F5D0FE" : cfg.trailColor,
                  life: 0,
                  maxLife: p.isOverdrive ? 0.6 : 0.45,
                });
              }
            }

            // Orb collision
            for (let i = orbsRef.current.length - 1; i >= 0; i--) {
              const orb = orbsRef.current[i];
              const pW = 0.09;
              const pH = 0.06;
              const hit = checkCircleCollision(p.x, 0.84, pW, orb.x, orb.y, 0.05);

              if (hit) {
                orbsRef.current.splice(i, 1);
                sounds.playOrb(p.combo);

                const points = orb.value * p.combo;
                p.score += points;
                p.orbsCollected++;
                p.combo = Math.min(5, p.combo + 1);
                p.comboTimer = 3.2;

                // Charge overdrive capacitor
                if (p.overdriveCapacitor < 3) {
                  p.overdriveCapacitor++;
                  if (p.overdriveCapacitor === 3 && !p.isOverdrive) {
                    p.isOverdrive = true;
                    p.overdriveTimer = 4.5;
                    sounds.playOverdrive();
                  }
                }

                // Add visual ripple
                ripplesRef.current.push({
                  x: orb.x,
                  y: orb.y,
                  radius: 8,
                  maxRadius: 45,
                  alpha: 0.8,
                  color: playerConfigs[pid].color,
                });

                // Add floating popup
                scorePopupsRef.current.push({
                  x: orb.x,
                  y: orb.y,
                  text: `+${points}`,
                  alpha: 1,
                  color: playerConfigs[pid].color,
                });
              }
            }

            // Obstacle collision
            if (p.invulnerableTimer <= 0) {
              const pW = 0.07;
              const pH = 0.07;
              for (const obs of obstaclesRef.current) {
                const hit = checkAABBCollision(
                  p.x - pW / 2,
                  p.x + pW / 2,
                  0.82 - pH / 2,
                  0.82 + pH / 2,
                  obs.x - obs.width / 2,
                  obs.x + obs.width / 2,
                  obs.y - obs.height / 2,
                  obs.y + obs.height / 2
                );

                if (hit) {
                  if (p.isOverdrive) {
                    // Overdrive crushes obstacle!
                    sounds.playOrb(3);
                    p.score += 250;
                    obs.y = 2.0; // remove
                    scorePopupsRef.current.push({
                      x: obs.x,
                      y: obs.y,
                      text: "SMASH! +250",
                      alpha: 1,
                      color: "#FDE047",
                    });
                  } else {
                    // Damage player
                    sounds.playCrash();
                    p.lives--;
                    p.combo = 1;
                    p.invulnerableTimer = 1.6;

                    if (p.lives <= 0) {
                      p.alive = false;
                    }
                  }
                  break;
                }
              }
            }

            next[pid] = p;
          });

          // Check game over
          if (livingCount === 0 && activePlayerIds.length > 0) {
            const scores: Record<PlayerId, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };
            activePlayerIds.forEach((pid) => (scores[pid] = next[pid].score));
            setTimeout(() => onGameOver(leaderId, scores), 100);
          }

          return next;
        });
      }

      // RENDER CANVAS
      render(ctx, canvas);
      animFrameRef.current = requestAnimationFrame(loop);
    };

    const render = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => {
      const w = canvas.width;
      const h = canvas.height;

      // Deep dark background
      ctx.fillStyle = "#0B0A10";
      ctx.fillRect(0, 0, w, h);

      // Cyber grid lines
      ctx.strokeStyle = "rgba(124, 106, 200, 0.12)";
      ctx.lineWidth = 1;

      const numCols = settings.playerCount > 1 ? settings.playerCount : 1;
      const colWidth = w / numCols;

      // Draw multi-player lanes if in split-screen mode
      for (let c = 0; c < numCols; c++) {
        const cx = c * colWidth;

        // Split border divider
        if (c > 0) {
          ctx.strokeStyle = "rgba(196, 181, 253, 0.25)";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(cx, 0);
          ctx.lineTo(cx, h);
          ctx.stroke();
        }

        // Subgrid perspective lines
        ctx.strokeStyle = "rgba(167, 139, 250, 0.08)";
        ctx.lineWidth = 1;
        for (let i = 1; i <= 3; i++) {
          const gx = cx + (colWidth * i) / 4;
          ctx.beginPath();
          ctx.moveTo(gx, 0);
          ctx.lineTo(gx, h);
          ctx.stroke();
        }
      }

      // Draw speed ripples on track
      const scrollOffset = (gameDurationRef.current * 220) % 60;
      ctx.strokeStyle = "rgba(196, 181, 253, 0.06)";
      ctx.lineWidth = 1.5;
      for (let y = scrollOffset; y < h; y += 60) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Draw obstacles
      obstaclesRef.current.forEach((obs) => {
        const ox = ((obs.x + 1) / 2) * w;
        const oy = obs.y * h;
        const ow = (obs.width / 2) * w;
        const oh = obs.height * h;

        ctx.save();
        ctx.shadowColor = "#EF4444";
        ctx.shadowBlur = 10;
        ctx.fillStyle = "rgba(239, 68, 68, 0.85)";
        ctx.strokeStyle = "#FCA5A5";
        ctx.lineWidth = 1.5;

        // Rounded barrier block
        ctx.beginPath();
        ctx.roundRect(ox - ow / 2, oy - oh / 2, ow, oh, 6);
        ctx.fill();
        ctx.stroke();

        // Warning hash marks
        ctx.fillStyle = "#FFFFFF";
        ctx.beginPath();
        ctx.arc(ox, oy, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw collectible orbs
      orbsRef.current.forEach((orb) => {
        const ox = ((orb.x + 1) / 2) * w;
        const oy = orb.y * h;
        const rad = orb.radius * (1 + 0.15 * Math.sin(orb.pulsePhase));

        ctx.save();
        ctx.shadowColor = "#C4B5FD";
        ctx.shadowBlur = 16;
        ctx.fillStyle = "#E9D5FF";
        ctx.beginPath();
        ctx.arc(ox, oy, rad, 0, Math.PI * 2);
        ctx.fill();

        // Pulsing ring
        ctx.strokeStyle = "rgba(196, 181, 253, 0.6)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(ox, oy, rad * 1.5, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      });

      // Draw particle trails (Tilt-to-Flow)
      particlesRef.current.forEach((p) => {
        const px = ((p.x + 1) / 2) * w;
        const py = p.y * h;
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(px, py, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw ripples
      ripplesRef.current.forEach((r) => {
        const rx = ((r.x + 1) / 2) * w;
        const ry = r.y * h;
        ctx.save();
        ctx.globalAlpha = r.alpha;
        ctx.strokeStyle = r.color;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(rx, ry, r.radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      });

      // Draw hovercraft for each active player
      activePlayerIds.forEach((pid, index) => {
        const p = playerStates[pid];
        const cfg = playerConfigs[pid];
        if (!p) return;

        // In multi-player split-screen, calculate localized lane X
        let px = ((p.x + 1) / 2) * w;
        if (numCols > 1) {
          const colX = index * colWidth;
          px = colX + ((p.x + 1) / 2) * colWidth;
        }

        const py = 0.84 * h;

        // Skip render if blinking from hit
        if (p.invulnerableTimer > 0 && Math.floor(p.invulnerableTimer * 12) % 2 === 0) {
          return;
        }

        ctx.save();
        if (!p.alive) {
          ctx.globalAlpha = 0.35;
        }

        // Overdrive aura
        if (p.isOverdrive) {
          ctx.shadowColor = "#F472B6";
          ctx.shadowBlur = 24;
          ctx.strokeStyle = "#F472B6";
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(px, py, 34, 0, Math.PI * 2);
          ctx.stroke();
        } else {
          ctx.shadowColor = cfg.glowColor;
          ctx.shadowBlur = 14;
        }

        // Hovercraft hull
        ctx.fillStyle = cfg.color;
        ctx.beginPath();
        ctx.moveTo(px, py - 20); // nose
        ctx.lineTo(px + 18, py + 16); // right wing
        ctx.lineTo(px + 8, py + 11);
        ctx.lineTo(px, py + 14); // center aft
        ctx.lineTo(px - 8, py + 11);
        ctx.lineTo(px - 18, py + 16); // left wing
        ctx.closePath();
        ctx.fill();

        // Cockpit canopy glass
        ctx.fillStyle = "#0B0A10";
        ctx.beginPath();
        ctx.ellipse(px, py - 4, 5, 9, 0, 0, Math.PI * 2);
        ctx.fill();

        // Player emoji / tag above ship
        ctx.font = "14px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(cfg.emoji, px, py - 28);

        ctx.restore();
      });

      // Draw score popups
      scorePopupsRef.current.forEach((sp) => {
        const sx = ((sp.x + 1) / 2) * w;
        const sy = sp.y * h;
        ctx.save();
        ctx.globalAlpha = sp.alpha;
        ctx.fillStyle = sp.color;
        ctx.font = "bold 16px 'Inter Tight', system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(sp.text, sx, sy);
        ctx.restore();
      });
    };

    lastTimeRef.current = performance.now();
    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      isRunning = false;
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [settings.playerCount, isPaused, activePlayerIds.length]);

  return (
    <div className="relative w-full h-[540px] md:h-[620px] rounded-2xl overflow-hidden bg-[#0B0A10] border border-purple-500/20 shadow-2xl">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
