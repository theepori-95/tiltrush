import test from "node:test";
import assert from "node:assert/strict";
import {
  normalizeTilt,
  generateRoomCode,
  checkAABBCollision,
  checkCircleCollision,
  calculateRatingDelta,
  getSpeedFactor,
} from "./rules.js";

test("normalizeTilt clamps and handles deadzone", () => {
  assert.equal(normalizeTilt(0, 0, "medium"), 0);
  assert.equal(normalizeTilt(1.0, 0, "medium"), 0); // within deadzone
  assert.equal(normalizeTilt(25, 0, "medium"), 1); // at max angle
  assert.equal(normalizeTilt(-25, 0, "medium"), -1);
  assert.equal(normalizeTilt(50, 0, "medium"), 1); // clamps
  assert.equal(normalizeTilt(-10, -10, "medium"), 0); // calibrated offset
});

test("generateRoomCode produces 6-character uppercase codes", () => {
  const code = generateRoomCode();
  assert.equal(code.length, 6);
  assert.match(code, /^[A-Z0-9]{6}$/);
});

test("checkAABBCollision correctly detects overlaps", () => {
  // Overlapping boxes
  assert.equal(checkAABBCollision(10, 30, 10, 30, 20, 40, 20, 40), true);
  // Separated horizontally
  assert.equal(checkAABBCollision(10, 20, 10, 20, 25, 35, 10, 20), false);
  // Separated vertically
  assert.equal(checkAABBCollision(10, 20, 10, 20, 10, 20, 25, 35), false);
});

test("checkCircleCollision correctly detects distance", () => {
  assert.equal(checkCircleCollision(0, 0, 10, 15, 0, 10), true);
  assert.equal(checkCircleCollision(0, 0, 5, 20, 0, 5), false);
});

test("calculateRatingDelta rewards high scores and bounds output", () => {
  const deltaHigh = calculateRatingDelta(2500, 1200, 60, 5);
  assert.ok(deltaHigh > 10);
  const deltaLow = calculateRatingDelta(50, 1800, 5, 1);
  assert.ok(deltaLow <= 0);
});

test("getSpeedFactor returns appropriate multipliers", () => {
  assert.equal(getSpeedFactor("chill"), 0.8);
  assert.equal(getSpeedFactor("neon"), 1.0);
  assert.equal(getSpeedFactor("warp"), 1.4);
});
