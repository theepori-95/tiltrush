export type PlayerId = 1 | 2 | 3 | 4;

export type GameType = "racing" | "ball_balance" | "maze_hunter";

export interface PlayerConfig {
  id: PlayerId;
  name: string;
  emoji: string;
  color: string;
  glowColor: string;
  trailColor: string;
  accentClass: string;
  keyLeft: string;
  keyRight: string;
  keyUp?: string;
  keyDown?: string;
  keyAction: string; // Jump in Ball Balance, Overdrive in Racing, Sprint in Maze
}

export const DEFAULT_PLAYERS: Record<PlayerId, PlayerConfig> = {
  1: {
    id: 1,
    name: "Player 1",
    emoji: "🛸",
    color: "#C4B5FD",
    glowColor: "#A78BFA",
    trailColor: "rgba(196, 181, 253, 0.7)",
    accentClass: "from-purple-500 to-indigo-500",
    keyLeft: "ArrowLeft",
    keyRight: "ArrowRight",
    keyUp: "ArrowUp",
    keyDown: "ArrowDown",
    keyAction: "Space",
  },
  2: {
    id: 2,
    name: "Player 2",
    emoji: "⚡",
    color: "#38BDF8",
    glowColor: "#0284C7",
    trailColor: "rgba(56, 189, 248, 0.7)",
    accentClass: "from-cyan-500 to-blue-500",
    keyLeft: "KeyA",
    keyRight: "KeyD",
    keyUp: "KeyW",
    keyDown: "KeyS",
    keyAction: "KeyE",
  },
  3: {
    id: 3,
    name: "Player 3",
    emoji: "🏎️",
    color: "#FBBF24",
    glowColor: "#D97706",
    trailColor: "rgba(251, 191, 36, 0.7)",
    accentClass: "from-amber-500 to-orange-500",
    keyLeft: "KeyJ",
    keyRight: "KeyL",
    keyUp: "KeyI",
    keyDown: "KeyK",
    keyAction: "KeyO",
  },
  4: {
    id: 4,
    name: "Player 4",
    emoji: "👾",
    color: "#34D399",
    glowColor: "#059669",
    trailColor: "rgba(52, 211, 153, 0.7)",
    accentClass: "from-emerald-500 to-teal-500",
    keyLeft: "Numpad4",
    keyRight: "Numpad6",
    keyUp: "Numpad8",
    keyDown: "Numpad5",
    keyAction: "Numpad0",
  },
};

export const AVAILABLE_EMOJIS = ["🛸", "⚡", "🏎️", "👾", "🚀", "🌌", "🔮", "🧿", "🦊", "🤖", "🐯", "💎"];

export interface GameSettings {
  gameType: GameType;
  playerCount: 1 | 2 | 3 | 4;
  speedMode: "chill" | "neon" | "warp";
  durationMode: "endless" | "timed" | "first_to_score";
  targetScore: number;
  timeLimitSeconds: number;
  initialLives: number;
  tiltSensitivity: "low" | "medium" | "high";
  hapticsEnabled: boolean;
  soundEnabled: boolean;
}

export interface PlayerGameState {
  id: PlayerId;
  x: number; // normalized -1 to 1 (or gridX)
  y: number; // normalized 0 to 1 (or gridY)
  targetX: number;
  targetY: number;
  score: number;
  lives: number;
  combo: number;
  comboTimer: number; // seconds left
  overdriveCapacitor: number; // 0 to 3
  isOverdrive: boolean;
  overdriveTimer: number;
  alive: boolean;
  invulnerableTimer: number;
  orbsCollected: number;
  obstaclesDodged: number;
  connected: boolean;
  calibrated: boolean;
  neutralRoll: number;
  neutralPitch: number;
  rttMs: number;
  // Specific to Ball Balancing:
  isJumping: boolean;
  jumpVelocity: number;
  jumpHeight: number;
  altitude: number;
  // Specific to Maze Hunter:
  gridCol: number;
  gridRow: number;
  pelletsEaten: number;
  hasKey: boolean;
  escaped: boolean;
}

export interface Obstacle {
  id: number;
  y: number; // 0 to 1
  x: number; // -1 to 1
  width: number;
  height: number;
  speed: number;
  color?: string;
  isCeilingHazard?: boolean; // For Ball Balance game
}

export interface Orb {
  id: number;
  y: number;
  x: number;
  radius: number;
  pulsePhase: number;
  value: number;
  type?: "regular" | "boost" | "key";
}

export interface HunterEnemy {
  x: number;
  y: number;
  gridCol: number;
  gridRow: number;
  targetCol: number;
  targetRow: number;
  speed: number;
  aggroTarget: PlayerId;
  color: string;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  color: string;
  life: number;
  maxLife: number;
}

export interface Ripple {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  alpha: number;
  color: string;
}

export interface ScorePopup {
  x: number;
  y: number;
  text: string;
  alpha: number;
  color: string;
}

export interface GameHistoryEntry {
  id: string;
  timestamp: number;
  dateStr: string;
  gameType: GameType;
  playerMode: "1P Solo" | "2P Duel" | "3P Trio" | "4P Royale";
  playerCount: number;
  winnerName: string;
  winnerEmoji: string;
  winnerScore: number;
  ratingAfter: number; // Chess.com style rating
  ratingDelta: number;
  durationSeconds: number;
  accuracyPercent: number;
  maxCombo: number;
  totalOrbs: number;
  status: "Victory" | "Personal Best" | "Crash" | "Escaped" | "Caught" | "Completed";
}
