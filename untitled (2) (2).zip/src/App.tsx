import React, { useState, useEffect, useRef } from "react";
import type {
  PlayerId,
  GameSettings,
  PlayerConfig,
  PlayerGameState,
  GameHistoryEntry,
  GameType,
} from "./types/game";
import { DEFAULT_PLAYERS } from "./types/game";
import { LaptopGameScreen } from "./components/LaptopGameScreen";
import { MultiplayerQRHub } from "./components/MultiplayerQRHub";
import { RatingHistoryGraph } from "./components/RatingHistoryGraph";
import { HallOfFame } from "./components/HallOfFame";
import { RulesAndLore } from "./components/RulesAndLore";
import { ControllerScreen } from "./components/ControllerScreen";
import HalftoneWordmarkFooter from "@/components/ui/halftone-wordmark-footer";
import { GameSocketClient } from "./net/socket";
import { generateRoomCode } from "./game/rules";
import { sounds } from "./utils/audio";
import { ThreeNeonArena } from "./game/ThreeNeonArena";
import { BioScienceLab } from "./components/BioScienceLab";
import { LyriaMusicStudio } from "./components/LyriaMusicStudio";
import { signInWithGoogle, logOut, getFirebaseAuth } from "./firebase/config";
import type { User } from "firebase/auth";
import {
  Gamepad2,
  TrendingUp,
  QrCode,
  Trophy,
  BookOpen,
  Smartphone,
  Radio,
  Wifi,
  Sparkles,
  Box,
  Dna,
  Music,
  LogIn,
  LogOut,
  User as UserIcon,
} from "lucide-react";

type Subpage = "arena" | "threejs-3d" | "history" | "multiplayer" | "bioscience" | "audio-studio" | "controller-lab" | "hall-of-fame" | "lore";

export default function App() {
  // Check if phone controller mode is requested in URL
  const [isPhoneMode, setIsPhoneMode] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      return params.get("mode") === "controller";
    }
    return false;
  });

  const [urlParams] = useState(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      return {
        room: params.get("room") || generateRoomCode(),
        player: (Number(params.get("player")) || 1) as PlayerId,
        game: (params.get("game") as GameType) || "racing",
      };
    }
    return { room: "NEON01", player: 1 as PlayerId, game: "racing" as GameType };
  });

  const [roomCode] = useState<string>(urlParams.room);
  const [currentTab, setCurrentTab] = useState<Subpage>("arena");

  // Game Settings State
  const [settings, setSettings] = useState<GameSettings>({
    gameType: urlParams.game,
    playerCount: 2,
    speedMode: "neon",
    durationMode: "endless",
    targetScore: 2500,
    timeLimitSeconds: 90,
    initialLives: 3,
    tiltSensitivity: "medium",
    hapticsEnabled: true,
    soundEnabled: true,
  });

  // Player configurations
  const [playerConfigs, setPlayerConfigs] = useState<Record<PlayerId, PlayerConfig>>(DEFAULT_PLAYERS);

  // Player live telemetry states
  const [playerStates, setPlayerStates] = useState<Record<PlayerId, PlayerGameState>>({
    1: {
      id: 1,
      x: 0,
      y: 0.8,
      targetX: 0,
      targetY: 0,
      score: 0,
      lives: 3,
      combo: 1,
      comboTimer: 0,
      overdriveCapacitor: 0,
      isOverdrive: false,
      overdriveTimer: 0,
      alive: true,
      invulnerableTimer: 0,
      orbsCollected: 0,
      obstaclesDodged: 0,
      connected: false,
      calibrated: false,
      neutralRoll: 0,
      neutralPitch: 0,
      rttMs: 0,
      isJumping: false,
      jumpVelocity: 0,
      jumpHeight: 0,
      altitude: 0,
      gridCol: 1,
      gridRow: 1,
      pelletsEaten: 0,
      hasKey: false,
      escaped: false,
    },
    2: {
      id: 2,
      x: 0,
      y: 0.8,
      targetX: 0,
      targetY: 0,
      score: 0,
      lives: 3,
      combo: 1,
      comboTimer: 0,
      overdriveCapacitor: 0,
      isOverdrive: false,
      overdriveTimer: 0,
      alive: true,
      invulnerableTimer: 0,
      orbsCollected: 0,
      obstaclesDodged: 0,
      connected: false,
      calibrated: false,
      neutralRoll: 0,
      neutralPitch: 0,
      rttMs: 0,
      isJumping: false,
      jumpVelocity: 0,
      jumpHeight: 0,
      altitude: 0,
      gridCol: 13,
      gridRow: 1,
      pelletsEaten: 0,
      hasKey: false,
      escaped: false,
    },
    3: {
      id: 3,
      x: 0,
      y: 0.8,
      targetX: 0,
      targetY: 0,
      score: 0,
      lives: 3,
      combo: 1,
      comboTimer: 0,
      overdriveCapacitor: 0,
      isOverdrive: false,
      overdriveTimer: 0,
      alive: true,
      invulnerableTimer: 0,
      orbsCollected: 0,
      obstaclesDodged: 0,
      connected: false,
      calibrated: false,
      neutralRoll: 0,
      neutralPitch: 0,
      rttMs: 0,
      isJumping: false,
      jumpVelocity: 0,
      jumpHeight: 0,
      altitude: 0,
      gridCol: 1,
      gridRow: 13,
      pelletsEaten: 0,
      hasKey: false,
      escaped: false,
    },
    4: {
      id: 4,
      x: 0,
      y: 0.8,
      targetX: 0,
      targetY: 0,
      score: 0,
      lives: 3,
      combo: 1,
      comboTimer: 0,
      overdriveCapacitor: 0,
      isOverdrive: false,
      overdriveTimer: 0,
      alive: true,
      invulnerableTimer: 0,
      orbsCollected: 0,
      obstaclesDodged: 0,
      connected: false,
      calibrated: false,
      neutralRoll: 0,
      neutralPitch: 0,
      rttMs: 0,
      isJumping: false,
      jumpVelocity: 0,
      jumpHeight: 0,
      altitude: 0,
      gridCol: 13,
      gridRow: 13,
      pelletsEaten: 0,
      hasKey: false,
      escaped: false,
    },
  });

  // Starter Historical Data (like Chess.com rating progression)
  const [matchHistory, setMatchHistory] = useState<GameHistoryEntry[]>(() => {
    return [
      {
        id: "run-init-1",
        timestamp: Date.now() - 3600000 * 5,
        dateStr: "18:20",
        gameType: "racing",
        playerMode: "1P Solo",
        playerCount: 1,
        winnerName: "Neon Violet",
        winnerEmoji: "🛸",
        winnerScore: 1240,
        ratingAfter: 1225,
        ratingDelta: 25,
        durationSeconds: 48,
        accuracyPercent: 78,
        maxCombo: 3,
        totalOrbs: 12,
        status: "Completed",
      },
      {
        id: "run-init-2",
        timestamp: Date.now() - 3600000 * 3,
        dateStr: "20:15",
        gameType: "ball_balance",
        playerMode: "2P Duel",
        playerCount: 2,
        winnerName: "Cyber Cyan",
        winnerEmoji: "⚡",
        winnerScore: 2180,
        ratingAfter: 1272,
        ratingDelta: 47,
        durationSeconds: 65,
        accuracyPercent: 86,
        maxCombo: 4,
        totalOrbs: 18,
        status: "Victory",
      },
      {
        id: "run-init-3",
        timestamp: Date.now() - 3600000 * 2,
        dateStr: "21:40",
        gameType: "maze_hunter",
        playerMode: "2P Duel",
        playerCount: 2,
        winnerName: "Neon Violet",
        winnerEmoji: "🛸",
        winnerScore: 2850,
        ratingAfter: 1320,
        ratingDelta: 48,
        durationSeconds: 72,
        accuracyPercent: 92,
        maxCombo: 5,
        totalOrbs: 24,
        status: "Escaped",
      },
      {
        id: "run-init-4",
        timestamp: Date.now() - 3600000,
        dateStr: "22:30",
        gameType: "racing",
        playerMode: "4P Royale",
        playerCount: 4,
        winnerName: "Solar Amber",
        winnerEmoji: "🏎️",
        winnerScore: 3410,
        ratingAfter: 1385,
        ratingDelta: 65,
        durationSeconds: 88,
        accuracyPercent: 95,
        maxCombo: 5,
        totalOrbs: 32,
        status: "Personal Best",
      },
    ];
  });

  const socketClientRef = useRef<GameSocketClient | null>(null);

  // Sync sound settings with audio manager
  useEffect(() => {
    sounds.enabled = settings.soundEnabled;
  }, [settings.soundEnabled]);

  // Laptop host WebSocket listener
  useEffect(() => {
    if (isPhoneMode) return;

    const client = new GameSocketClient("/ws");
    socketClientRef.current = client;

    client.connect(() => {
      client.send({
        t: "create",
        room: roomCode.toUpperCase(),
      });
    });

    const unsubscribe = client.subscribe((msg) => {
      if (msg.t === "player_connected") {
        setPlayerStates((prev) => ({
          ...prev,
          [msg.player]: { ...prev[msg.player], connected: true },
        }));
      }

      if (msg.t === "player_disconnected") {
        setPlayerStates((prev) => ({
          ...prev,
          [msg.player]: { ...prev[msg.player], connected: false },
        }));
      }

      if (msg.t === "tilt") {
        setPlayerStates((prev) => {
          const current = prev[msg.player];
          if (!current) return prev;
          return {
            ...prev,
            [msg.player]: {
              ...current,
              targetX: msg.x,
              targetY: msg.y !== undefined ? msg.y : current.targetY,
            },
          };
        });
      }

      if (msg.t === "action") {
        setPlayerStates((prev) => {
          const p = prev[msg.player];
          if (!p) return prev;

          if (msg.actionType === "jump" && !p.isJumping) {
            sounds.playBeep(true);
            return {
              ...prev,
              [msg.player]: { ...p, isJumping: true, jumpVelocity: 1.3 },
            };
          }

          if (msg.actionType === "overdrive" && !p.isOverdrive) {
            sounds.playOverdrive();
            return {
              ...prev,
              [msg.player]: { ...p, isOverdrive: true, overdriveTimer: 4.5 },
            };
          }

          if (msg.actionType === "sprint") {
            sounds.playOrb(3);
            return {
              ...prev,
              [msg.player]: { ...p, score: p.score + 50 },
            };
          }

          return prev;
        });
      }

      if (msg.t === "calibrate") {
        setPlayerStates((prev) => {
          const p = prev[msg.player];
          if (!p) return prev;
          return {
            ...prev,
            [msg.player]: {
              ...p,
              calibrated: true,
              neutralRoll: msg.roll,
              neutralPitch: msg.pitch || 0,
            },
          };
        });
      }
    });

    const rttInterval = setInterval(() => {
      if (client) {
        setPlayerStates((prev) => {
          const next = { ...prev };
          ([1, 2, 3, 4] as PlayerId[]).forEach((pid) => {
            if (next[pid].connected) {
              next[pid].rttMs = client.rtt;
            }
          });
          return next;
        });
      }
    }, 1200);

    return () => {
      clearInterval(rttInterval);
      unsubscribe();
      client.destroy();
    };
  }, [isPhoneMode, roomCode]);

  // If this device opened in phone controller mode, render ControllerScreen exclusively
  if (isPhoneMode) {
    return (
      <ControllerScreen
        initialRoomCode={urlParams.room}
        initialPlayerId={urlParams.player}
        initialGameType={settings.gameType}
      />
    );
  }

  const handleUpdatePlayerConfig = (pid: PlayerId, patch: Partial<PlayerConfig>) => {
    setPlayerConfigs((prev) => ({
      ...prev,
      [pid]: { ...prev[pid], ...patch },
    }));
  };

  const handleGameCompleted = (entry: GameHistoryEntry) => {
    setMatchHistory((prev) => [...prev, entry]);
  };

  const connectedCount = ([1, 2, 3, 4] as PlayerId[])
    .slice(0, settings.playerCount)
    .filter((pid) => playerStates[pid]?.connected).length;

  return (
    <div className="min-h-screen bg-[#0B0A10] text-[#F5F3FA] flex flex-col justify-between selection:bg-purple-500/30 font-sans antialiased">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#0B0A10]/90 backdrop-blur-md border-b border-purple-500/15 px-4 sm:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Logo & Product Identity */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-purple-500/30 text-white font-black text-lg">
              TR
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-wide text-white">TiltRush</span>
                <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  NEON ESCAPE
                </span>
              </div>
              <p className="text-[11px] text-gray-400">
                “Your phone. Your reflexes. One unforgettable run.”
              </p>
            </div>
          </div>

          {/* Subpage Tabs Navigation */}
          <nav className="flex items-center gap-1.5 bg-[#12101A] p-1.5 rounded-2xl border border-purple-500/20 overflow-x-auto max-w-full text-xs">
            <button
              onClick={() => setCurrentTab("arena")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "arena"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <Gamepad2 className="w-3.5 h-3.5 text-purple-400" />
              2D Arena
            </button>

            <button
              onClick={() => setCurrentTab("threejs-3d")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "threejs-3d"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <Box className="w-3.5 h-3.5 text-purple-400" />
              Three.js 3D
            </button>

            <button
              onClick={() => setCurrentTab("history")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "history"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-purple-400" />
              Rating & History
            </button>

            <button
              onClick={() => setCurrentTab("multiplayer")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "multiplayer"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <QrCode className="w-3.5 h-3.5 text-purple-400" />
              QR Station
            </button>

            <button
              onClick={() => setCurrentTab("bioscience")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "bioscience"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <Dna className="w-3.5 h-3.5 text-purple-400" />
              BioScience
            </button>

            <button
              onClick={() => setCurrentTab("audio-studio")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "audio-studio"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <Music className="w-3.5 h-3.5 text-purple-400" />
              Lyria & AI
            </button>

            <button
              onClick={() => setCurrentTab("hall-of-fame")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "hall-of-fame"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              Hall of Fame
            </button>

            <button
              onClick={() => setCurrentTab("controller-lab")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "controller-lab"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-purple-400" />
              Sensor Lab
            </button>

            <button
              onClick={() => setCurrentTab("lore")}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                currentTab === "lore"
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-purple-400" />
              Lore
            </button>
          </nav>

          {/* Right Status Badge */}
          <div className="flex items-center gap-2.5">
            <div className="bg-[#12101A] border border-purple-500/20 px-3 py-1.5 rounded-xl text-xs font-mono flex items-center gap-2">
              <span className="text-gray-400">ROOM:</span>
              <span className="text-purple-300 font-bold tracking-wider">{roomCode}</span>
            </div>

            <div
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 ${
                connectedCount > 0
                  ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
                  : "bg-purple-500/10 text-purple-300 border border-purple-500/20"
              }`}
            >
              <Radio className="w-3.5 h-3.5 animate-pulse text-purple-400" />
              <span>{connectedCount} Phone Connected</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Subpages */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-8 py-6 space-y-8 flex-1">
        {currentTab === "arena" && (
          <LaptopGameScreen
            roomCode={roomCode}
            settings={settings}
            onUpdateSettings={setSettings}
            playerConfigs={playerConfigs}
            onUpdatePlayerConfig={handleUpdatePlayerConfig}
            playerStates={playerStates}
            onUpdatePlayerStates={setPlayerStates}
            onGameCompleted={handleGameCompleted}
            onOpenQRHub={() => setCurrentTab("multiplayer")}
          />
        )}

        {currentTab === "threejs-3d" && (
          <ThreeNeonArena
            settings={settings}
            playerConfigs={playerConfigs}
            playerStates={playerStates}
            onUpdatePlayerStates={setPlayerStates}
            onGameOver={(winnerId, scores) => {
              const delta = 45;
              handleGameCompleted({
                id: "run-3d-" + Date.now(),
                timestamp: Date.now(),
                dateStr: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                gameType: "racing",
                playerMode: "1P Solo",
                playerCount: 1,
                winnerName: playerConfigs[winnerId].name,
                winnerEmoji: playerConfigs[winnerId].emoji,
                winnerScore: scores[winnerId] || 1500,
                ratingAfter: 1445,
                ratingDelta: delta,
                durationSeconds: 60,
                accuracyPercent: 90,
                maxCombo: 4,
                totalOrbs: 12,
                status: "Victory",
              });
            }}
            roomCode={roomCode}
          />
        )}

        {currentTab === "bioscience" && <BioScienceLab />}

        {currentTab === "audio-studio" && <LyriaMusicStudio />}

        {currentTab === "history" && (
          <RatingHistoryGraph history={matchHistory} currentScore={playerStates[1]?.score || 0} />
        )}

        {currentTab === "multiplayer" && (
          <MultiplayerQRHub
            roomCode={roomCode}
            playerConfigs={playerConfigs}
            playerStates={playerStates}
            playerCount={settings.playerCount}
          />
        )}

        {currentTab === "hall-of-fame" && <HallOfFame />}

        {currentTab === "controller-lab" && (
          <div className="space-y-6">
            <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-6 shadow-2xl">
              <h3 className="text-lg font-bold text-purple-200 mb-1 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-purple-400" />
                Live In-Browser Motion Sensor Simulator & Lab
              </h3>
              <p className="text-xs text-gray-400 mb-6">
                Test tilt physics, calibrate neutral angles, and preview how your mobile device controls each hovercraft slot.
              </p>
              <div className="max-w-md mx-auto">
                <ControllerScreen
                  initialRoomCode={roomCode}
                  initialPlayerId={1}
                  initialGameType={settings.gameType}
                />
              </div>
            </div>
          </div>
        )}

        {currentTab === "lore" && <RulesAndLore />}
      </main>

      {/* Integrated Halftone Wordmark Footer with TiltRush Theme */}
      <HalftoneWordmarkFooter
        wordmark="tiltrush"
        label="TiltRush: Neon Escape"
        meta="©2026 · Anything But A Game Controller Hackathon"
        height="380px"
        preset="night"
        palette={{
          background: "#0B0A10",
          ink: "#C4B5FD",
          warm: "#A78BFA",
        }}
      />
    </div>
  );
}
