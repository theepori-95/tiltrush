import React, { useState, useEffect, useRef } from "react";
import { Music, Mic, MapPin, Image, Play, Pause, Sparkles, Volume2, Search, Sliders } from "lucide-react";

export const LyriaMusicStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"music" | "voice" | "maps" | "image">("music");

  // Lyria Music State
  const [selectedPreset, setSelectedPreset] = useState("synthwave");
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);
  const [bpm, setBpm] = useState(132);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const musicTimerRef = useRef<number | null>(null);

  // Voice Conversation State
  const [isListening, setIsListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState("Say 'Launch Neon Escape' or 'Calibrate Controller'...");
  const [aiResponse, setAiResponse] = useState("Ready for voice commands. Microphone active.");

  // Maps State
  const [mapQuery, setMapQuery] = useState("Tokyo Akihabara VR Arcade");
  const [mapResults, setMapResults] = useState([
    { name: "Sega GiGO Arcade Akihabara", location: "Chiyoda, Tokyo", rating: 4.8, dist: "0.4 km", tag: "Esports Arena" },
    { name: "Neo Cyber Games Lounge", location: "Shibuya, Tokyo", rating: 4.9, dist: "2.1 km", tag: "VR Motion Simulators" },
    { name: "Hikarigaoka Retro Gaming Hub", location: "Nerima, Tokyo", rating: 4.7, dist: "5.3 km", tag: "Indie Arcade" },
  ]);

  // Image Creation State
  const [imagePrompt, setImagePrompt] = useState("Supersonic lavender hovercraft racing in cyber rain, high resolution, dark neon aesthetic");
  const [isGeneratingImg, setIsGeneratingImg] = useState(false);
  const [generatedImg, setGeneratedImg] = useState<string | null>(null);

  // Procedural Web Audio Synth for Lyria Music Generator
  const togglePlayMusic = () => {
    if (isPlayingMusic) {
      if (musicTimerRef.current) clearInterval(musicTimerRef.current);
      musicTimerRef.current = null;
      setIsPlayingMusic(false);
      return;
    }

    if (!audioCtxRef.current) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtxRef.current = new AudioCtx();
    }
    if (audioCtxRef.current.state === "suspended") {
      audioCtxRef.current.resume();
    }

    const ctx = audioCtxRef.current;
    let step = 0;
    const intervalMs = (60 / bpm / 2) * 1000;

    // Arpeggio scales based on preset
    const scale = selectedPreset === "synthwave" ? [220, 261.63, 329.63, 392, 440, 523.25] : [196, 233.08, 293.66, 349.23, 392, 466.16];

    musicTimerRef.current = window.setInterval(() => {
      if (!ctx) return;
      const t = ctx.currentTime;

      // Synth Arpeggio
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const freq = scale[step % scale.length];

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.08, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.19);

      // Bass Kick on beat
      if (step % 2 === 0) {
        const kick = ctx.createOscillator();
        const kickGain = ctx.createGain();
        kick.type = "sine";
        kick.frequency.setValueAtTime(120, t);
        kick.frequency.exponentialRampToValueAtTime(32, t + 0.22);
        kickGain.gain.setValueAtTime(0.24, t);
        kickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
        kick.connect(kickGain);
        kickGain.connect(ctx.destination);
        kick.start(t);
        kick.stop(t + 0.23);
      }

      step++;
    }, intervalMs);

    setIsPlayingMusic(true);
  };

  useEffect(() => {
    return () => {
      if (musicTimerRef.current) clearInterval(musicTimerRef.current);
    };
  }, []);

  const handleVoiceToggle = () => {
    if (!isListening) {
      setIsListening(true);
      setVoiceTranscript("Listening to voice commands...");
      // Simulate live recognition
      setTimeout(() => {
        setVoiceTranscript("Command recognized: 'Activate 3D Neon Arena'");
        setAiResponse("Command processed! Switching simulation to 3D Three.js PBR Engine.");
        setIsListening(false);
      }, 2500);
    } else {
      setIsListening(false);
    }
  };

  const handleGenerateImage = () => {
    setIsGeneratingImg(true);
    setTimeout(() => {
      setIsGeneratingImg(false);
      // Generate procedural SVG representation
      setGeneratedImg(
        "data:image/svg+xml;utf8," +
          encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" width="400" height="260" viewBox="0 0 400 260">
          <rect width="100%" height="100%" fill="#0B0A10"/>
          <path d="M 0 160 Q 200 130 400 160 L 400 260 L 0 260 Z" fill="#12101A"/>
          <line x1="0" y1="180" x2="400" y2="180" stroke="#A78BFA" stroke-width="1.5" opacity="0.4"/>
          <polygon points="200,80 240,170 210,160 200,165 190,160 160,170" fill="#C4B5FD"/>
          <circle cx="200" cy="115" r="10" fill="#0B0A10"/>
          <ellipse cx="200" cy="180" rx="30" ry="6" fill="#000" opacity="0.6"/>
          <text x="200" y="240" fill="#C4B5FD" font-family="sans-serif" font-size="12" text-anchor="middle" font-weight="bold">TILTRUSH PROCEDURAL CONCEPT SKIN</text>
        </svg>
      `)
      );
    }, 1200);
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-6 shadow-2xl">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-purple-500/10 pb-4 mb-5 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab("music")}
            className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-2 transition-all ${
              activeTab === "music" ? "bg-purple-600/30 text-purple-200 border border-purple-500/40" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <Music className="w-3.5 h-3.5 text-purple-400" /> Lyria Music Generation
          </button>
          <button
            onClick={() => setActiveTab("voice")}
            className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-2 transition-all ${
              activeTab === "voice" ? "bg-purple-600/30 text-purple-200 border border-purple-500/40" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <Mic className="w-3.5 h-3.5 text-purple-400" /> Gemini Live Voice
          </button>
          <button
            onClick={() => setActiveTab("maps")}
            className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-2 transition-all ${
              activeTab === "maps" ? "bg-purple-600/30 text-purple-200 border border-purple-500/40" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <MapPin className="w-3.5 h-3.5 text-purple-400" /> Maps Grounding
          </button>
          <button
            onClick={() => setActiveTab("image")}
            className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-2 transition-all ${
              activeTab === "image" ? "bg-purple-600/30 text-purple-200 border border-purple-500/40" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <Image className="w-3.5 h-3.5 text-purple-400" /> Gemini Image Studio
          </button>
        </div>

        {/* Tab 1: Lyria Music Studio */}
        {activeTab === "music" && (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Lyria Arcade Soundtrack Studio
                <Sparkles className="w-4 h-4 text-purple-400" />
              </h3>
              <p className="text-xs text-gray-400">
                Compose procedural adaptive soundtracks for TiltRush using Lyria-3 models and synchronized Web Audio synthesis
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-[#0B0A10] border border-purple-500/20 rounded-xl p-4 space-y-3">
                <label className="text-xs font-mono uppercase text-purple-300 font-bold">Soundtrack Theme</label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[
                    { id: "synthwave", name: "Neon Synthwave", bpm: 132 },
                    { id: "hyperspeed", name: "Dark Lavender Warp", bpm: 145 },
                    { id: "retro", name: "8-Bit Overdrive", bpm: 128 },
                    { id: "ambient", name: "Zero-G Deep Cosmos", bpm: 110 },
                  ].map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setSelectedPreset(p.id);
                        setBpm(p.bpm);
                      }}
                      className={`p-2.5 rounded-lg border text-left ${
                        selectedPreset === p.id
                          ? "bg-purple-600/25 border-purple-400 text-white font-bold"
                          : "bg-[#12101A] border-purple-500/10 text-gray-400"
                      }`}
                    >
                      <div>{p.name}</div>
                      <div className="text-[10px] text-purple-400 font-mono">{p.bpm} BPM</div>
                    </button>
                  ))}
                </div>

                <div className="pt-2 flex items-center justify-between text-xs font-mono text-gray-400">
                  <span>TEMPO: {bpm} BPM</span>
                  <input
                    type="range"
                    min="100"
                    max="160"
                    value={bpm}
                    onChange={(e) => setBpm(Number(e.target.value))}
                    className="accent-purple-500"
                  />
                </div>
              </div>

              {/* Music Player Control */}
              <div className="bg-[#0B0A10] border border-purple-500/20 rounded-xl p-4 flex flex-col justify-between items-center text-center space-y-3">
                <div className="p-3 bg-purple-500/10 rounded-full text-purple-400">
                  <Volume2 className="w-8 h-8" />
                </div>
                <div>
                  <div className="text-sm font-bold text-white uppercase tracking-wider">
                    {selectedPreset} Adaptive Stream
                  </div>
                  <div className="text-[11px] text-gray-400 font-mono mt-0.5">
                    {isPlayingMusic ? "Active · Synced to Game Loop" : "Ready to Stream"}
                  </div>
                </div>

                <button
                  onClick={togglePlayMusic}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-2"
                >
                  {isPlayingMusic ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                  {isPlayingMusic ? "PAUSE SOUNDTRACK" : "STREAM LYRIA TRACK"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Gemini Live Voice */}
        {activeTab === "voice" && (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Gemini Live Voice Pilot Interface
                <Mic className="w-4 h-4 text-purple-400" />
              </h3>
              <p className="text-xs text-gray-400">
                Control game state, calibration, and player lobbies using real-time speech interaction
              </p>
            </div>

            <div className="bg-[#0B0A10] border border-purple-500/20 rounded-xl p-5 space-y-4">
              <div className="p-4 bg-[#12101A] rounded-xl border border-purple-500/20 space-y-2">
                <div className="text-[10px] font-mono text-gray-400 uppercase">Input Audio Stream:</div>
                <div className="text-sm text-purple-200 font-medium">{voiceTranscript}</div>
              </div>

              <div className="p-4 bg-purple-950/20 rounded-xl border border-purple-500/30 space-y-2">
                <div className="text-[10px] font-mono text-purple-400 uppercase">Gemini Live Output:</div>
                <div className="text-sm text-white font-bold">{aiResponse}</div>
              </div>

              <button
                onClick={handleVoiceToggle}
                className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                  isListening
                    ? "bg-rose-600 text-white animate-pulse"
                    : "bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-500/25"
                }`}
              >
                <Mic className="w-4 h-4" />
                {isListening ? "STOP LISTENING" : "START VOICE CONVERSATION"}
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Maps Grounding */}
        {activeTab === "maps" && (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Google Maps Grounding & Esports Lounges
                <MapPin className="w-4 h-4 text-purple-400" />
              </h3>
              <p className="text-xs text-gray-400">
                Discover verified arcade tournaments, gaming cafes, and VR motion simulation arenas
              </p>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={mapQuery}
                onChange={(e) => setMapQuery(e.target.value)}
                placeholder="Search gaming center..."
                className="flex-1 bg-[#0B0A10] border border-purple-500/20 rounded-xl px-3.5 py-2 text-xs text-white outline-none"
              />
              <button className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5" /> Search
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {mapResults.map((place) => (
                <div key={place.name} className="bg-[#0B0A10] border border-purple-500/20 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white">{place.name}</span>
                    <span className="text-amber-400 font-bold">★ {place.rating}</span>
                  </div>
                  <div className="text-[11px] text-gray-400">{place.location}</div>
                  <div className="flex justify-between items-center pt-2 border-t border-purple-500/10 text-[10px] font-mono">
                    <span className="text-purple-300">{place.tag}</span>
                    <span className="text-gray-400">{place.dist}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Gemini Image Studio */}
        {activeTab === "image" && (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Gemini Image Generation & Skin Customizer
                <Image className="w-4 h-4 text-purple-400" />
              </h3>
              <p className="text-xs text-gray-400">
                Design bespoke hovercraft paint skins, custom decals, and sci-fi arena backgrounds
              </p>
            </div>

            <div className="space-y-3">
              <textarea
                value={imagePrompt}
                onChange={(e) => setImagePrompt(e.target.value)}
                rows={2}
                className="w-full bg-[#0B0A10] border border-purple-500/20 rounded-xl p-3 text-xs text-white outline-none resize-none"
              />
              <button
                onClick={handleGenerateImage}
                disabled={isGeneratingImg}
                className="px-6 py-2.5 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold rounded-xl text-xs shadow-lg flex items-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isGeneratingImg ? "GENERATING SKIN..." : "GENERATE HOVERCRAFT SKIN"}
              </button>
            </div>

            {generatedImg && (
              <div className="p-3 bg-[#0B0A10] border border-purple-500/30 rounded-xl flex items-center justify-center">
                <img src={generatedImg} alt="Generated Skin" className="rounded-lg max-h-56 object-contain" />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
