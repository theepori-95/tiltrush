import React, { useEffect, useState } from "react";
import QRCode from "qrcode";
import type { PlayerConfig, PlayerGameState, PlayerId } from "../types/game";
import { QrCode, Smartphone, Wifi, WifiOff, Copy, Check, ExternalLink } from "lucide-react";

interface Props {
  roomCode: string;
  playerConfigs: Record<PlayerId, PlayerConfig>;
  playerStates: Record<PlayerId, PlayerGameState>;
  playerCount: 1 | 2 | 3 | 4;
}

export const MultiplayerQRHub: React.FC<Props> = ({
  roomCode,
  playerConfigs,
  playerStates,
  playerCount,
}) => {
  const [qrDataUrls, setQrDataUrls] = useState<Record<PlayerId, string>>({
    1: "",
    2: "",
    3: "",
    4: "",
  });
  const [copiedId, setCopiedId] = useState<number | null>(null);

  useEffect(() => {
    const origin = typeof window !== "undefined" ? window.location.origin : "http://localhost:3000";

    const generateQRs = async () => {
      const urls: Record<PlayerId, string> = { 1: "", 2: "", 3: "", 4: "" };
      for (const id of [1, 2, 3, 4] as PlayerId[]) {
        const fullUrl = `${origin}/?mode=controller&room=${roomCode}&player=${id}`;
        try {
          const qr = await QRCode.toDataURL(fullUrl, {
            margin: 1,
            color: {
              dark: playerConfigs[id].color,
              light: "#0B0A10",
            },
            width: 220,
          });
          urls[id] = qr;
        } catch (e) {
          console.error("Error generating QR", e);
        }
      }
      setQrDataUrls(urls);
    };

    generateQRs();
  }, [roomCode, playerConfigs]);

  const copyPlayerUrl = (pid: PlayerId) => {
    const origin = typeof window !== "undefined" ? window.location.origin : "";
    const url = `${origin}/?mode=controller&room=${roomCode}&player=${pid}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopiedId(pid);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const activeIds = ([1, 2, 3, 4] as PlayerId[]).slice(0, playerCount);

  return (
    <div className="space-y-6">
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-purple-500/10 pb-5 mb-6">
          <div>
            <h3 className="text-xl font-bold text-purple-100 flex items-center gap-2.5">
              <QrCode className="w-6 h-6 text-purple-400" />
              Multiplayer QR Pairing Station
            </h3>
            <p className="text-sm text-gray-400 mt-1">
              Each player gets their own assigned color, emoji, and dedicated QR code. Scan with your phone's camera to turn it into a motion tilt controller!
            </p>
          </div>
          <div className="flex items-center gap-2 bg-[#0B0A10] px-4 py-2 rounded-xl border border-purple-500/30">
            <span className="text-xs text-gray-400 uppercase tracking-widest font-mono">Room Code:</span>
            <span className="text-lg font-bold font-mono text-purple-300">{roomCode}</span>
          </div>
        </div>

        {/* QR Code Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {activeIds.map((pid) => {
            const cfg = playerConfigs[pid];
            const state = playerStates[pid];
            const isConnected = state?.connected;

            return (
              <div
                key={pid}
                className="bg-[#0B0A10] border rounded-2xl p-5 flex flex-col items-center text-center relative overflow-hidden transition-all shadow-xl hover:border-purple-400/50"
                style={{ borderColor: `${cfg.color}35` }}
              >
                {/* Top Badge */}
                <div className="w-full flex items-center justify-between mb-3 text-xs">
                  <span
                    className="font-bold px-2 py-0.5 rounded-md flex items-center gap-1.5"
                    style={{ backgroundColor: `${cfg.color}20`, color: cfg.color }}
                  >
                    <span>{cfg.emoji}</span>
                    <span>{cfg.name}</span>
                  </span>
                  <span
                    className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono ${
                      isConnected
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                        : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                    }`}
                  >
                    {isConnected ? (
                      <>
                        <Wifi className="w-3 h-3 text-emerald-400 animate-pulse" /> CONNECTED
                      </>
                    ) : (
                      <>
                        <WifiOff className="w-3 h-3 text-amber-400" /> SCAN QR
                      </>
                    )}
                  </span>
                </div>

                {/* QR Canvas Box */}
                <div className="relative p-2.5 rounded-xl bg-[#12101A] border border-purple-500/20 my-2 shadow-inner group">
                  {qrDataUrls[pid] ? (
                    <img
                      src={qrDataUrls[pid]}
                      alt={`QR Code for ${cfg.name}`}
                      className="w-44 h-44 rounded-lg block"
                    />
                  ) : (
                    <div className="w-44 h-44 flex items-center justify-center text-xs text-gray-500 font-mono">
                      Generating QR...
                    </div>
                  )}

                  {/* QR Scan Helper Overlay */}
                  <div className="absolute inset-0 bg-[#0B0A10]/80 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-3">
                    <Smartphone className="w-8 h-8 text-purple-300" />
                    <span className="text-[11px] text-purple-200 text-center font-medium">
                      Point phone camera at this QR code
                    </span>
                  </div>
                </div>

                {/* Status Telemetry */}
                <div className="w-full mt-3 pt-3 border-t border-purple-500/10 space-y-1 text-xs text-gray-400">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span>Latency RTT:</span>
                    <span className="text-purple-300 font-bold">{state?.rttMs ? `${state.rttMs} ms` : "—"}</span>
                  </div>
                  <div className="flex justify-between font-mono text-[11px]">
                    <span>Calibration:</span>
                    <span className={state?.calibrated ? "text-emerald-400 font-bold" : "text-gray-400"}>
                      {state?.calibrated ? "Calibrated" : "Auto 0°"}
                    </span>
                  </div>
                  <div className="flex justify-between font-mono text-[11px]">
                    <span>Keys Fallback:</span>
                    <span className="text-gray-300">{cfg.keyLeft} / {cfg.keyRight}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="w-full flex items-center gap-2 mt-4">
                  <button
                    onClick={() => copyPlayerUrl(pid)}
                    className="flex-1 py-1.5 px-2 rounded-lg bg-[#191622] hover:bg-purple-900/30 text-purple-200 border border-purple-500/30 text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    {copiedId === pid ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedId === pid ? "Copied" : "Copy Link"}
                  </button>
                  <a
                    href={`/?mode=controller&room=${roomCode}&player=${pid}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 rounded-lg bg-[#191622] hover:bg-purple-900/30 text-purple-300 border border-purple-500/30 transition-colors"
                    title="Open Controller in New Tab for Local Testing"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
