export { default, hwfHex, hwfRadius, hwfStep, hwfWarmth, hwfFitSize } from "@/components/ui/halftone-wordmark-footer";
export type { HalftonePalette, HalftonePreset, FooterLink, FooterColumn, HalftoneWordmarkFooterProps } from "@/components/ui/halftone-wordmark-footer";
