import React, { useState, useEffect, useRef } from "react";
import type {
  PlayerConfig,
  PlayerGameState,
  GameSettings,
  GameHistoryEntry,
  PlayerId,
  GameType,
} from "../types/game";
import { NeonRacingCanvas } from "../game/NeonRacingCanvas";
import { BallBalanceCanvas } from "../game/BallBalanceCanvas";
import { MazeHunterCanvas } from "../game/MazeHunterCanvas";
import { PreGameOptionsModal } from "./PreGameOptionsModal";
import { calculateRatingDelta } from "../game/rules";
import { sounds } from "../utils/audio";
import {
  Play,
  Pause,
  RotateCcw,
  Settings,
  Trophy,
  Heart,
  Zap,
  Radio,
  ArrowUp,
  Sparkles,
  Award,
} from "lucide-react";
import confetti from "canvas-confetti";

interface Props {
  roomCode: string;
  settings: GameSettings;
  onUpdateSettings: (updater: (prev: GameSettings) => GameSettings) => void;
  playerConfigs: Record<PlayerId, PlayerConfig>;
  onUpdatePlayerConfig: (pid: PlayerId, patch: Partial<PlayerConfig>) => void;
  playerStates: Record<PlayerId, PlayerGameState>;
  onUpdatePlayerStates: (
    updater: (prev: Record<PlayerId, PlayerGameState>) => Record<PlayerId, PlayerGameState>
  ) => void;
  onGameCompleted: (entry: GameHistoryEntry) => void;
  onOpenQRHub: () => void;
}

export const LaptopGameScreen: React.FC<Props> = ({
  roomCode,
  settings,
  onUpdateSettings,
  playerConfigs,
  onUpdatePlayerConfig,
  playerStates,
  onUpdatePlayerStates,
  onGameCompleted,
  onOpenQRHub,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isOptionsOpen, setIsOptionsOpen] = useState(false);
  const [gameOverResult, setGameOverResult] = useState<{
    winnerId: PlayerId;
    scores: Record<PlayerId, number>;
  } | null>(null);

  const gameStartTimeRef = useRef<number>(0);

  // Keyboard controls listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || isPaused) return;

      const code = e.code;

      onUpdatePlayerStates((prev) => {
        const next = { ...prev };

        // Player 1
        if (code === "ArrowLeft") next[1] = { ...next[1], targetX: -0.85 };
        if (code === "ArrowRight") next[1] = { ...next[1], targetX: 0.85 };
        if (code === "ArrowUp") next[1] = { ...next[1], targetY: -0.85 };
        if (code === "ArrowDown") next[1] = { ...next[1], targetY: 0.85 };
        if (code === "Space") {
          // Action (Jump in Ball Balance, Overdrive in Racing, Sprint in Maze)
          if (settings.gameType === "ball_balance" && !next[1].isJumping) {
            sounds.playBeep(true);
            next[1] = { ...next[1], isJumping: true, jumpVelocity: 1.3 };
          } else if (settings.gameType === "racing" && next[1].overdriveCapacitor >= 3 && !next[1].isOverdrive) {
            sounds.playOverdrive();
            next[1] = { ...next[1], isOverdrive: true, overdriveTimer: 4.5 };
          }
        }

        // Player 2
        if (settings.playerCount >= 2) {
          if (code === "KeyA") next[2] = { ...next[2], targetX: -0.85 };
          if (code === "KeyD") next[2] = { ...next[2], targetX: 0.85 };
          if (code === "KeyW") next[2] = { ...next[2], targetY: -0.85 };
          if (code === "KeyS") next[2] = { ...next[2], targetY: 0.85 };
          if (code === "KeyE") {
            if (settings.gameType === "ball_balance" && !next[2].isJumping) {
              sounds.playBeep(true);
              next[2] = { ...next[2], isJumping: true, jumpVelocity: 1.3 };
            } else if (settings.gameType === "racing" && next[2].overdriveCapacitor >= 3 && !next[2].isOverdrive) {
              sounds.playOverdrive();
              next[2] = { ...next[2], isOverdrive: true, overdriveTimer: 4.5 };
            }
          }
        }

        // Player 3
        if (settings.playerCount >= 3) {
          if (code === "KeyJ") next[3] = { ...next[3], targetX: -0.85 };
          if (code === "KeyL") next[3] = { ...next[3], targetX: 0.85 };
          if (code === "KeyI") next[3] = { ...next[3], targetY: -0.85 };
          if (code === "KeyK") next[3] = { ...next[3], targetY: 0.85 };
          if (code === "KeyO") {
            if (settings.gameType === "ball_balance" && !next[3].isJumping) {
              next[3] = { ...next[3], isJumping: true, jumpVelocity: 1.3 };
            }
          }
        }

        return next;
      });
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const code = e.code;
      onUpdatePlayerStates((prev) => {
        const next = { ...prev };
        if (code === "ArrowLeft" || code === "ArrowRight") next[1] = { ...next[1], targetX: 0 };
        if (code === "ArrowUp" || code === "ArrowDown") next[1] = { ...next[1], targetY: 0 };

        if (code === "KeyA" || code === "KeyD") next[2] = { ...next[2], targetX: 0 };
        if (code === "KeyW" || code === "KeyS") next[2] = { ...next[2], targetY: 0 };

        if (code === "KeyJ" || code === "KeyL") next[3] = { ...next[3], targetX: 0 };
        if (code === "KeyI" || code === "KeyK") next[3] = { ...next[3], targetY: 0 };

        return next;
      });
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [isPlaying, isPaused, settings.gameType, settings.playerCount]);

  const handleStartGame = () => {
    setGameOverResult(null);
    gameStartTimeRef.current = Date.now();
    sounds.playBeep(true);

    onUpdatePlayerStates((prev) => {
      const next = { ...prev };
      ([1, 2, 3, 4] as PlayerId[]).forEach((pid) => {
        next[pid] = {
          ...next[pid],
          score: 0,
          lives: 3,
          combo: 1,
          comboTimer: 0,
          alive: true,
          isOverdrive: false,
          overdriveTimer: 0,
          overdriveCapacitor: 0,
          invulnerableTimer: 0.8,
          orbsCollected: 0,
          obstaclesDodged: 0,
          isJumping: false,
          jumpHeight: 0,
          altitude: 0,
          escaped: false,
          hasKey: false,
          pelletsEaten: 0,
        };
      });
      return next;
    });

    setIsPlaying(true);
    setIsPaused(false);
  };

  const handleGameOver = (winnerId: PlayerId, finalScores: Record<PlayerId, number>) => {
    setIsPlaying(false);
    setGameOverResult({ winnerId, scores: finalScores });

    const duration = Math.max(1, Math.round((Date.now() - gameStartTimeRef.current) / 1000));
    const winnerCfg = playerConfigs[winnerId];
    const topScore = finalScores[winnerId] || 0;

    // Trigger celebratory confetti for the champion!
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ["#C4B5FD", "#A78BFA", "#38BDF8", "#FBBF24"],
      });
    } catch {}

    const modeLabels: Record<1 | 2 | 3 | 4, "1P Solo" | "2P Duel" | "3P Trio" | "4P Royale"> = {
      1: "1P Solo",
      2: "2P Duel",
      3: "3P Trio",
      4: "4P Royale",
    };

    const delta = calculateRatingDelta(topScore, 1400, duration, 5);

    const entry: GameHistoryEntry = {
      id: "run-" + Date.now(),
      timestamp: Date.now(),
      dateStr: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      gameType: settings.gameType,
      playerMode: modeLabels[settings.playerCount],
      playerCount: settings.playerCount,
      winnerName: winnerCfg.name,
      winnerEmoji: winnerCfg.emoji,
      winnerScore: topScore,
      ratingAfter: 1400 + delta,
      ratingDelta: delta,
      durationSeconds: duration,
      accuracyPercent: Math.min(100, Math.max(65, 75 + Math.round(Math.random() * 20))),
      maxCombo: 5,
      totalOrbs: playerStates[winnerId]?.orbsCollected || 8,
      status: topScore > 1500 ? "Victory" : "Completed",
    };

    onGameCompleted(entry);
  };

  const activeIds = ([1, 2, 3, 4] as PlayerId[]).slice(0, settings.playerCount);

  return (
    <div className="space-y-6">
      {/* Pre-Game Options Modal */}
      <PreGameOptionsModal
        isOpen={isOptionsOpen}
        onClose={() => setIsOptionsOpen(false)}
        settings={settings}
        onUpdateSettings={onUpdateSettings}
        playerConfigs={playerConfigs}
        onUpdatePlayerConfig={onUpdatePlayerConfig}
        onStartGame={handleStartGame}
      />

      {/* Top Game Navigation & Control Bar */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-4 shadow-2xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-purple-500/15 border border-purple-500/30 text-purple-300">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white tracking-wide">
                {settings.gameType === "racing"
                  ? "🏎️ NEON RACING"
                  : settings.gameType === "ball_balance"
                  ? "🔮 BALL ASCENT & JUMP"
                  : "👾 CYBER MAZE HUNTER"}
              </h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                {settings.playerCount}P Split Screen
              </span>
            </div>
            <p className="text-xs text-gray-400">
              {settings.gameType === "racing"
                ? "Tilt phone roll to steer hovercraft · Collect orbs for Overdrive"
                : settings.gameType === "ball_balance"
                ? "Balance ascending sphere · Press JUMP to dodge roof crushers!"
                : "Pac-Man style maze · Devour pellets, find Key & escape Hunter"}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsOptionsOpen(true)}
            className="py-2 px-3.5 rounded-xl bg-[#191622] hover:bg-purple-900/30 text-purple-200 border border-purple-500/30 text-xs font-bold flex items-center gap-1.5 transition-all"
          >
            <Settings className="w-3.5 h-3.5 text-purple-400" />
            Match Options
          </button>

          <button
            onClick={onOpenQRHub}
            className="py-2 px-3.5 rounded-xl bg-[#191622] hover:bg-purple-900/30 text-purple-200 border border-purple-500/30 text-xs font-bold flex items-center gap-1.5 transition-all"
          >
            <Radio className="w-3.5 h-3.5 text-purple-400" />
            QR Phone Hub
          </button>

          {!isPlaying ? (
            <button
              onClick={handleStartGame}
              className="py-2 px-5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-bold text-xs shadow-lg shadow-purple-500/25 flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              START GAME
            </button>
          ) : (
            <>
              <button
                onClick={() => setIsPaused(!isPaused)}
                className="py-2 px-3 rounded-xl bg-[#191622] text-gray-300 hover:text-white border border-purple-500/20 text-xs font-bold flex items-center gap-1"
              >
                {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                {isPaused ? "Resume" : "Pause"}
              </button>
              <button
                onClick={handleStartGame}
                className="py-2 px-3 rounded-xl bg-[#191622] text-gray-300 hover:text-white border border-purple-500/20 text-xs font-bold flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Restart
              </button>
            </>
          )}
        </div>
      </div>

      {/* Multi-Player Scoreboard HUD Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {activeIds.map((pid) => {
          const cfg = playerConfigs[pid];
          const st = playerStates[pid];

          return (
            <div
              key={pid}
              className="bg-[#12101A] border rounded-xl p-3 shadow-lg flex items-center justify-between relative overflow-hidden"
              style={{ borderColor: `${cfg.color}35` }}
            >
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">{cfg.emoji}</span>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>{cfg.name}</span>
                    {st?.connected && (
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    )}
                  </div>
                  <div className="text-lg font-bold font-mono text-amber-300">
                    {st ? st.score.toLocaleString() : 0}{" "}
                    <span className="text-[10px] text-gray-400 font-normal">pts</span>
                  </div>
                </div>
              </div>

              {/* Lives & Combo */}
              <div className="text-right space-y-1">
                <div className="flex items-center gap-0.5 justify-end text-rose-500">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Heart
                      key={i}
                      className={`w-3.5 h-3.5 ${
                        st && i < st.lives ? "fill-rose-500" : "text-gray-700"
                      }`}
                    />
                  ))}
                </div>

                <div className="text-[10px] font-mono text-purple-300">
                  {st?.isOverdrive ? (
                    <span className="text-pink-400 font-bold animate-pulse">OVERDRIVE!</span>
                  ) : st?.isJumping ? (
                    <span className="text-cyan-300 font-bold">JUMPING!</span>
                  ) : st && st.combo > 1 ? (
                    <span className="text-amber-400 font-bold">{st.combo}x COMBO</span>
                  ) : (
                    <span className="text-gray-400">1x</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Canvas Viewport with Overlay States */}
      <div className="relative">
        {settings.gameType === "racing" ? (
          <NeonRacingCanvas
            settings={settings}
            playerConfigs={playerConfigs}
            playerStates={playerStates}
            onUpdatePlayerStates={onUpdatePlayerStates}
            onGameOver={handleGameOver}
            isPaused={isPaused || !isPlaying}
          />
        ) : settings.gameType === "ball_balance" ? (
          <BallBalanceCanvas
            settings={settings}
            playerConfigs={playerConfigs}
            playerStates={playerStates}
            onUpdatePlayerStates={onUpdatePlayerStates}
            onGameOver={handleGameOver}
            isPaused={isPaused || !isPlaying}
          />
        ) : (
          <MazeHunterCanvas
            settings={settings}
            playerConfigs={playerConfigs}
            playerStates={playerStates}
            onUpdatePlayerStates={onUpdatePlayerStates}
            onGameOver={handleGameOver}
            isPaused={isPaused || !isPlaying}
          />
        )}

        {/* Start Game Hero Overlay if not running */}
        {!isPlaying && !gameOverResult && (
          <div className="absolute inset-0 bg-[#0B0A10]/75 backdrop-blur-sm rounded-2xl flex flex-col items-center justify-center p-6 text-center space-y-4">
            <div className="p-3 bg-purple-500/10 rounded-2xl border border-purple-500/20 text-purple-300">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-2xl md:text-3xl font-extrabold text-white tracking-wide">
              {settings.gameType === "racing"
                ? "READY FOR NEON ESCAPE?"
                : settings.gameType === "ball_balance"
                ? "READY FOR BALL ASCENT?"
                : "READY FOR CYBER MAZE HUNTER?"}
            </h3>
            <p className="text-sm text-gray-400 max-w-md">
              Scan the QR code with your smartphone or use desktop keys (← / → and Space) to launch your run!
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handleStartGame}
                className="py-3 px-8 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-bold text-sm shadow-xl shadow-purple-500/30 flex items-center gap-2"
              >
                <Play className="w-4 h-4 fill-white" />
                LAUNCH ARENA
              </button>
              <button
                onClick={() => setIsOptionsOpen(true)}
                className="py-3 px-6 rounded-xl bg-[#191622] hover:bg-purple-900/30 text-purple-200 border border-purple-500/30 text-sm font-bold flex items-center gap-2"
              >
                <Settings className="w-4 h-4 text-purple-400" />
                Change Mode / Players
              </button>
            </div>
          </div>
        )}

        {/* Game Over Victory / Results Overlay */}
        {gameOverResult && (
          <div className="absolute inset-0 bg-[#0B0A10]/90 backdrop-blur-md rounded-2xl flex flex-col items-center justify-center p-6 text-center space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 bg-amber-500/15 rounded-full text-amber-400 border border-amber-500/30 shadow-xl shadow-amber-500/20">
              <Trophy className="w-10 h-10" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-widest font-mono text-purple-300">
                Arena Match Completed
              </div>
              <h3 className="text-3xl font-extrabold text-white mt-1 flex items-center justify-center gap-2">
                <span>{playerConfigs[gameOverResult.winnerId].emoji}</span>
                <span>{playerConfigs[gameOverResult.winnerId].name} Wins!</span>
              </h3>
            </div>

            {/* Final Scores Breakdown */}
            <div className="bg-[#12101A] border border-purple-500/20 rounded-xl p-4 w-full max-w-md space-y-2 text-xs">
              {activeIds.map((pid) => (
                <div
                  key={pid}
                  className="flex items-center justify-between py-1 border-b border-purple-500/10 last:border-0"
                >
                  <span className="flex items-center gap-2 font-medium text-gray-300">
                    <span>{playerConfigs[pid].emoji}</span>
                    <span>{playerConfigs[pid].name}</span>
                  </span>
                  <span className="font-mono font-bold text-amber-300">
                    {(gameOverResult.scores[pid] || 0).toLocaleString()} pts
                  </span>
                </div>
              ))}
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={handleStartGame}
                className="py-3 px-8 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-bold text-sm shadow-xl shadow-purple-500/30 flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                PLAY AGAIN
              </button>
              <button
                onClick={() => setIsOptionsOpen(true)}
                className="py-3 px-5 rounded-xl bg-[#191622] hover:bg-purple-900/30 text-purple-200 border border-purple-500/30 text-sm font-bold"
              >
                Change Game
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
