import React, { useState, useEffect, useRef } from "react";
import type { PlayerId, GameType } from "../types/game";
import { normalizeTilt } from "../game/rules";
import { GameSocketClient } from "../net/socket";
import { Smartphone, Compass, CheckCircle2, AlertTriangle, Radio, RotateCcw, Zap, ArrowUp } from "lucide-react";

interface Props {
  initialRoomCode?: string;
  initialPlayerId?: PlayerId;
  initialGameType?: GameType;
}

export const ControllerScreen: React.FC<Props> = ({
  initialRoomCode = "NEON01",
  initialPlayerId = 1,
  initialGameType = "racing",
}) => {
  const [roomCode, setRoomCode] = useState(initialRoomCode);
  const [playerId, setPlayerId] = useState<PlayerId>(initialPlayerId);
  const [gameType, setGameType] = useState<GameType>(initialGameType);
  const [isConnected, setIsConnected] = useState(false);
  const [motionSupported, setMotionSupported] = useState(false);
  const [motionEnabled, setMotionEnabled] = useState(false);
  const [calibrated, setCalibrated] = useState(false);
  const [neutralRoll, setNeutralRoll] = useState(0);
  const [neutralPitch, setNeutralPitch] = useState(0);
  const [rawRoll, setRawRoll] = useState(0);
  const [rawPitch, setRawPitch] = useState(0);
  const [steerValue, setSteerValue] = useState(0);
  const [pitchSteerValue, setPitchSteerValue] = useState(0);
  const [sensitivity, setSensitivity] = useState<"low" | "medium" | "high">("medium");
  const [rtt, setRtt] = useState(0);
  const [haptics, setHaptics] = useState(true);

  const socketClientRef = useRef<GameSocketClient | null>(null);
  const seqCounterRef = useRef(1);
  const lastSendTimeRef = useRef(0);

  // Initialize socket
  useEffect(() => {
    const client = new GameSocketClient("/ws");
    socketClientRef.current = client;

    client.connect(() => {
      setIsConnected(true);
      client.send({
        t: "join",
        room: roomCode.toUpperCase(),
        player: playerId,
      });
    });

    const unsubscribe = client.subscribe((msg) => {
      if (msg.t === "joined") {
        setIsConnected(true);
      }
      if (msg.t === "game_select") {
        setGameType(msg.gameType);
      }
    });

    const rttInterval = setInterval(() => {
      setRtt(client.rtt);
      setIsConnected(client.isConnected);
    }, 1000);

    return () => {
      clearInterval(rttInterval);
      unsubscribe();
      client.destroy();
    };
  }, [roomCode, playerId]);

  // Check orientation sensor availability
  useEffect(() => {
    if (typeof window !== "undefined" && "DeviceOrientationEvent" in window) {
      setMotionSupported(true);
    }
  }, []);

  const triggerHaptic = (ms = 25) => {
    if (haptics && typeof navigator !== "undefined" && navigator.vibrate) {
      navigator.vibrate(ms);
    }
  };

  const requestMotionPermission = async () => {
    triggerHaptic(40);
    if (
      typeof DeviceOrientationEvent !== "undefined" &&
      // @ts-expect-error iOS Safari permission API
      typeof DeviceOrientationEvent.requestPermission === "function"
    ) {
      try {
        // @ts-expect-error iOS Safari permission API
        const permission = await DeviceOrientationEvent.requestPermission();
        if (permission === "granted") {
          setMotionEnabled(true);
          startOrientationListener();
        } else {
          alert("Motion sensor permission was denied. You can use on-screen touch steering!");
        }
      } catch (err) {
        console.error("Permission request failed", err);
      }
    } else {
      // Android / Standard browsers
      setMotionEnabled(true);
      startOrientationListener();
    }
  };

  const startOrientationListener = () => {
    window.addEventListener("deviceorientation", handleOrientation);
  };

  const handleOrientation = (e: DeviceOrientationEvent) => {
    const gamma = e.gamma || 0; // Roll: -90 to 90
    const beta = e.beta || 0; // Pitch: -180 to 180

    setRawRoll(gamma);
    setRawPitch(beta);

    const normX = normalizeTilt(gamma, neutralRoll, sensitivity);
    const normY = normalizeTilt(beta, neutralPitch, sensitivity);

    setSteerValue(normX);
    setPitchSteerValue(normY);

    // Throttle to 30Hz (~33ms)
    const now = Date.now();
    if (now - lastSendTimeRef.current >= 33 && socketClientRef.current) {
      lastSendTimeRef.current = now;
      socketClientRef.current.send({
        t: "tilt",
        room: roomCode.toUpperCase(),
        player: playerId,
        x: normX,
        y: normY,
        seq: seqCounterRef.current++,
      });
    }
  };

  const calibrateNeutral = () => {
    triggerHaptic(50);
    setNeutralRoll(rawRoll);
    setNeutralPitch(rawPitch);
    setCalibrated(true);

    if (socketClientRef.current) {
      socketClientRef.current.send({
        t: "calibrate",
        room: roomCode.toUpperCase(),
        player: playerId,
        roll: rawRoll,
        pitch: rawPitch,
      });
    }
  };

  const sendAction = (actionType: "jump" | "overdrive" | "sprint") => {
    triggerHaptic(60);
    if (socketClientRef.current) {
      socketClientRef.current.send({
        t: "action",
        room: roomCode.toUpperCase(),
        player: playerId,
        actionType,
      });
    }
  };

  const handleManualTouchSteer = (direction: -1 | 1 | 0) => {
    triggerHaptic(15);
    setSteerValue(direction);
    if (socketClientRef.current) {
      socketClientRef.current.send({
        t: "tilt",
        room: roomCode.toUpperCase(),
        player: playerId,
        x: direction,
        y: 0,
        seq: seqCounterRef.current++,
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0A10] text-[#F5F3FA] flex flex-col justify-between p-4 sm:p-6 select-none font-sans">
      {/* Top Header */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-purple-400" />
            <span className="font-bold text-sm tracking-wide text-purple-200">
              TiltRush Controller
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full ${
                isConnected
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                  : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
              }`}
            >
              <Radio className="w-3 h-3 animate-pulse" />
              {isConnected ? "CONNECTED" : "RECONNECTING"}
            </span>

            {isConnected && (
              <span className="bg-[#191622] px-2 py-1 rounded-md text-purple-300 border border-purple-500/20">
                {rtt} ms
              </span>
            )}
          </div>
        </div>

        {/* Room & Player Slot Selectors */}
        <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-purple-500/10 text-xs">
          <div>
            <label className="text-gray-400 font-mono text-[10px] uppercase">Room Code</label>
            <input
              type="text"
              value={roomCode}
              onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
              className="w-full bg-[#0B0A10] border border-purple-500/20 rounded-lg px-2.5 py-1 text-purple-200 font-mono font-bold uppercase mt-0.5"
            />
          </div>
          <div>
            <label className="text-gray-400 font-mono text-[10px] uppercase">Player Slot</label>
            <select
              value={playerId}
              onChange={(e) => setPlayerId(Number(e.target.value) as PlayerId)}
              className="w-full bg-[#0B0A10] border border-purple-500/20 rounded-lg px-2.5 py-1 text-purple-200 font-bold mt-0.5 cursor-pointer"
            >
              <option value={1}>Player 1 (Violet 🛸)</option>
              <option value={2}>Player 2 (Cyan ⚡)</option>
              <option value={3}>Player 3 (Amber 🏎️)</option>
              <option value={4}>Player 4 (Emerald 👾)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Motion Visualizer Center */}
      <div className="my-auto py-4 space-y-4">
        {/* Sensor Permission / Activation Button */}
        {!motionEnabled ? (
          <div className="bg-[#12101A] border border-purple-500/30 rounded-2xl p-6 text-center shadow-xl space-y-3">
            <div className="p-3 bg-purple-500/10 rounded-full w-14 h-14 mx-auto flex items-center justify-center text-purple-400">
              <Compass className="w-7 h-7 animate-spin" />
            </div>
            <h3 className="font-bold text-base text-purple-100">Activate Gyroscope Motion</h3>
            <p className="text-xs text-gray-400 max-w-xs mx-auto">
              TiltRush uses your smartphone's real gyroscope to steer hovercrafts, balance balls, and explore mazes.
            </p>
            <button
              onClick={requestMotionPermission}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-bold text-sm shadow-lg shadow-purple-500/30 flex items-center justify-center gap-2"
            >
              <Smartphone className="w-4 h-4" />
              ENABLE MOTION SENSORS
            </button>
          </div>
        ) : (
          <div className="bg-[#12101A] border border-purple-500/30 rounded-2xl p-5 text-center shadow-xl space-y-3">
            {/* Live Horizon Bubble Meter */}
            <div className="flex items-center justify-between text-xs font-mono text-gray-400">
              <span>REAL-TIME TILT</span>
              <span className="text-purple-300 font-bold">{(steerValue * 100).toFixed(0)}%</span>
            </div>

            <div className="relative h-14 bg-[#0B0A10] border border-purple-500/20 rounded-xl overflow-hidden flex items-center justify-center">
              {/* Center Zero Tick */}
              <div className="absolute h-full w-0.5 bg-purple-500/40 z-10" />

              {/* Dynamic Bubble Indicator */}
              <div
                className="absolute w-8 h-8 rounded-full bg-gradient-to-r from-purple-400 to-indigo-400 shadow-lg shadow-purple-500/50 flex items-center justify-center text-[10px] font-bold text-white transition-all duration-75"
                style={{
                  left: `calc(50% + ${steerValue * 42}% - 16px)`,
                }}
              >
                ●
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-gray-400">
              <span>ROLL: {rawRoll.toFixed(1)}°</span>
              <span>PITCH: {rawPitch.toFixed(1)}°</span>
            </div>

            {/* Calibration Button */}
            <button
              onClick={calibrateNeutral}
              className="w-full py-2.5 rounded-xl bg-[#191622] hover:bg-purple-900/40 text-purple-200 border border-purple-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5 text-purple-400" />
              {calibrated ? "RE-CALIBRATE NEUTRAL ZERO" : "CALIBRATE NEUTRAL HOLDING ANGLE"}
            </button>
          </div>
        )}

        {/* Dynamic Action Trigger Button based on Game Mode */}
        <div className="space-y-2">
          {gameType === "ball_balance" ? (
            <button
              onClick={() => sendAction("jump")}
              className="w-full py-5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 active:scale-95 text-white font-extrabold text-base shadow-xl shadow-cyan-500/25 flex items-center justify-center gap-2.5 uppercase tracking-wider"
            >
              <ArrowUp className="w-6 h-6 stroke-[3]" />
              JUMP / LEAP OVER ROOF CRUSHER!
            </button>
          ) : gameType === "maze_hunter" ? (
            <button
              onClick={() => sendAction("sprint")}
              className="w-full py-5 rounded-2xl bg-gradient-to-r from-rose-500 to-pink-600 active:scale-95 text-white font-extrabold text-base shadow-xl shadow-rose-500/25 flex items-center justify-center gap-2.5 uppercase tracking-wider"
            >
              <Zap className="w-6 h-6 fill-white" />
              PULSE SPRINT / EMP STUN!
            </button>
          ) : (
            <button
              onClick={() => sendAction("overdrive")}
              className="w-full py-5 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 active:scale-95 text-white font-extrabold text-base shadow-xl shadow-purple-500/25 flex items-center justify-center gap-2.5 uppercase tracking-wider"
            >
              <Zap className="w-6 h-6 fill-white" />
              ACTIVATE NEON OVERDRIVE!
            </button>
          )}
        </div>

        {/* Touch Steering Fallback Pads */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            onTouchStart={() => handleManualTouchSteer(-1)}
            onTouchEnd={() => handleManualTouchSteer(0)}
            onMouseDown={() => handleManualTouchSteer(-1)}
            onMouseUp={() => handleManualTouchSteer(0)}
            className="py-4 bg-[#12101A] active:bg-purple-900/50 border border-purple-500/20 rounded-xl font-bold text-sm text-purple-200 active:scale-95 transition-all text-center"
          >
            ◀ STEER LEFT
          </button>
          <button
            onTouchStart={() => handleManualTouchSteer(1)}
            onTouchEnd={() => handleManualTouchSteer(0)}
            onMouseDown={() => handleManualTouchSteer(1)}
            onMouseUp={() => handleManualTouchSteer(0)}
            className="py-4 bg-[#12101A] active:bg-purple-900/50 border border-purple-500/20 rounded-xl font-bold text-sm text-purple-200 active:scale-95 transition-all text-center"
          >
            STEER RIGHT ▶
          </button>
        </div>
      </div>

      {/* Bottom Controls (Sensitivity & Haptics) */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-3 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span className="text-gray-400 font-mono text-[11px]">SENSITIVITY:</span>
          {(["low", "medium", "high"] as const).map((lvl) => (
            <button
              key={lvl}
              onClick={() => setSensitivity(lvl)}
              className={`px-2 py-0.5 rounded text-[10px] uppercase font-mono ${
                sensitivity === lvl
                  ? "bg-purple-600 text-white font-bold"
                  : "bg-[#0B0A10] text-gray-400"
              }`}
            >
              {lvl}
            </button>
          ))}
        </div>

        <button
          onClick={() => setHaptics(!haptics)}
          className={`px-2 py-1 rounded text-[11px] font-mono ${
            haptics ? "text-purple-300" : "text-gray-500"
          }`}
        >
          {haptics ? "Vibrate: ON" : "Vibrate: OFF"}
        </button>
      </div>
    </div>
  );
};
