import React from "react";
import { Trophy, Medal, Star, Flame, Target, Compass, Sparkles } from "lucide-react";

export const HallOfFame: React.FC = () => {
  const LEADERBOARD = [
    { rank: 1, name: "Neon Grandmaster", emoji: "🛸", score: 4920, rating: 1845, game: "Neon Racing", badge: "🥇 Diamond" },
    { rank: 2, name: "Warp Overlord", emoji: "⚡", score: 3840, rating: 1690, game: "Ball Ascent", badge: "🥈 Master" },
    { rank: 3, name: "Cyber Stalker Ace", emoji: "👾", score: 3210, rating: 1540, game: "Maze Hunter", badge: "🥉 Expert" },
    { rank: 4, name: "Solar Drifter", emoji: "🏎️", score: 2850, rating: 1480, game: "Neon Racing", badge: "Elite" },
    { rank: 5, name: "Void Walker", emoji: "🌌", score: 2430, rating: 1395, game: "Ball Ascent", badge: "Pro" },
    { rank: 6, name: "Orb Alchemist", emoji: "🔮", score: 2180, rating: 1350, game: "Maze Hunter", badge: "Challenger" },
  ];

  const BADGES = [
    {
      title: "Gyro Master",
      desc: "Maintain 90%+ steer accuracy using real mobile phone motion",
      emoji: "📱",
      unlocked: true,
      progress: "100%",
    },
    {
      title: "Orb Magnet",
      desc: "Collect over 50 Pulse Orbs in a single run with 5x combo",
      emoji: "🔮",
      unlocked: true,
      progress: "54 / 50",
    },
    {
      title: "Ceiling Leaper",
      desc: "Perform 12 high jumps over falling roof hazards in Ball Ascent",
      emoji: "🦘",
      unlocked: true,
      progress: "12 / 12",
    },
    {
      title: "Maze Infiltrator",
      desc: "Recover the Golden Access Key and escape the Cyber Hunter",
      emoji: "🔑",
      unlocked: true,
      progress: "Sector Cleared",
    },
    {
      title: "Split-Screen Gladiator",
      desc: "Win a 4-Player local multiplayer battle royale",
      emoji: "👑",
      unlocked: false,
      progress: "Rank 1 Needed",
    },
    {
      title: "Overdrive Hyperloop",
      desc: "Smash through 10 obstacle walls during a single Neon Overdrive",
      emoji: "⚡",
      unlocked: true,
      progress: "10 / 10",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Leaderboard Podium */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-purple-500/10 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-purple-100 flex items-center gap-2">
                Hall of Fame & Global High Scores
                <Sparkles className="w-4 h-4 text-amber-400" />
              </h3>
              <p className="text-xs text-gray-400">All-time record runs across all 3 motion arcade arenas</p>
            </div>
          </div>
          <span className="text-xs font-mono text-purple-300 bg-purple-500/10 px-3 py-1.5 rounded-xl border border-purple-500/20">
            Season 1 Active
          </span>
        </div>

        {/* Podium Top 3 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {LEADERBOARD.slice(0, 3).map((player, idx) => (
            <div
              key={player.rank}
              className={`p-5 rounded-2xl border relative overflow-hidden flex flex-col justify-between ${
                idx === 0
                  ? "bg-gradient-to-b from-amber-500/15 to-[#0B0A10] border-amber-500/40 shadow-xl shadow-amber-500/10"
                  : idx === 1
                  ? "bg-gradient-to-b from-purple-500/15 to-[#0B0A10] border-purple-400/40 shadow-xl shadow-purple-500/10"
                  : "bg-gradient-to-b from-cyan-500/15 to-[#0B0A10] border-cyan-400/40 shadow-xl shadow-cyan-500/10"
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-2xl">{player.badge.split(" ")[0]}</span>
                <span className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wider">
                  Rank #{player.rank}
                </span>
              </div>
              <div className="text-center my-2">
                <div className="text-4xl mb-1">{player.emoji}</div>
                <div className="font-bold text-base text-white">{player.name}</div>
                <div className="text-xs text-gray-400 font-mono mt-0.5">{player.game}</div>
              </div>
              <div className="pt-3 border-t border-purple-500/10 flex items-center justify-between text-xs">
                <span className="text-gray-400">Score:</span>
                <span className="text-lg font-bold font-mono text-amber-300">
                  {player.score.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Leaderboard Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0B0A10] text-purple-300/70 border-b border-purple-500/10">
              <tr>
                <th className="py-2.5 px-3">Rank</th>
                <th className="py-2.5 px-3">Pilot</th>
                <th className="py-2.5 px-3">Arena</th>
                <th className="py-2.5 px-3">Score</th>
                <th className="py-2.5 px-3">Rating</th>
                <th className="py-2.5 px-3">Tier Badge</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-500/10 text-gray-300">
              {LEADERBOARD.map((item) => (
                <tr key={item.rank} className="hover:bg-purple-500/5 transition-colors">
                  <td className="py-2.5 px-3 font-mono font-bold text-purple-300">#{item.rank}</td>
                  <td className="py-2.5 px-3 font-medium text-white flex items-center gap-2">
                    <span className="text-lg">{item.emoji}</span>
                    <span>{item.name}</span>
                  </td>
                  <td className="py-2.5 px-3 text-gray-400">{item.game}</td>
                  <td className="py-2.5 px-3 font-bold font-mono text-amber-300">
                    {item.score.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-purple-200">{item.rating}</td>
                  <td className="py-2.5 px-3">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-purple-500/20 text-purple-200 border border-purple-500/30">
                      {item.badge}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Unlockable Achievements Case */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-6 shadow-2xl">
        <h4 className="text-base font-bold text-purple-200 flex items-center gap-2 mb-4">
          <Medal className="w-5 h-5 text-purple-400" />
          Pilot Badges & Medals
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {BADGES.map((b) => (
            <div
              key={b.title}
              className={`p-4 rounded-xl border flex items-start gap-3.5 ${
                b.unlocked
                  ? "bg-[#0B0A10] border-purple-500/30 shadow-lg"
                  : "bg-[#0B0A10]/50 border-gray-800 opacity-60"
              }`}
            >
              <div className="text-3xl p-2 rounded-xl bg-purple-500/10 border border-purple-500/20">
                {b.emoji}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h5 className="font-bold text-xs text-white">{b.title}</h5>
                  {b.unlocked && <span className="text-[10px] text-emerald-400 font-bold">✓ UNLOCKED</span>}
                </div>
                <p className="text-[11px] text-gray-400 mt-0.5 leading-snug">{b.desc}</p>
                <div className="mt-2 text-[10px] font-mono text-purple-300/80">
                  Status: {b.progress}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
