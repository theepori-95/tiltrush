import React, { useState, useEffect, useRef } from "react";
import * as THREE from "three";
import { Dna, ExternalLink, ShieldCheck, Sparkles, Zap, Award, Activity } from "lucide-react";

interface MoleculeTarget {
  id: string;
  name: string;
  uniprotId: string;
  pdbId: string;
  category: "Oncology" | "Cardiovascular" | "Small Molecule";
  description: string;
  meanPLDDT: number;
  residues: number;
  provenance: "[AlphaFold DB Predicted]" | "[RCSB PDB Experimental]";
  externalUrl: string;
}

const PRESET_TARGETS: MoleculeTarget[] = [
  {
    id: "TP53",
    name: "Cellular Tumor Antigen p53",
    uniprotId: "P04637",
    pdbId: "1TUP",
    category: "Oncology",
    description: "Acts as a tumor suppressor in many tumor types; induces growth arrest or apoptosis.",
    meanPLDDT: 91.4,
    residues: 393,
    provenance: "[RCSB PDB Experimental]",
    externalUrl: "https://www.rcsb.org/structure/1TUP",
  },
  {
    id: "EGFR",
    name: "Epidermal Growth Factor Receptor",
    uniprotId: "P00533",
    pdbId: "1M17",
    category: "Oncology",
    description: "Receptor tyrosine kinase binding ligands of the EGF family and activating several signaling cascades.",
    meanPLDDT: 88.2,
    residues: 1210,
    provenance: "[AlphaFold DB Predicted]",
    externalUrl: "https://alphafold.ebi.ac.uk/entry/P00533",
  },
  {
    id: "BRCA1",
    name: "Breast Cancer Type 1 Susceptibility Protein",
    uniprotId: "P38398",
    pdbId: "1JNX",
    category: "Oncology",
    description: "E3 ubiquitin-protein ligase involved in DNA repair and maintenance of genomic stability.",
    meanPLDDT: 76.5,
    residues: 1863,
    provenance: "[AlphaFold DB Predicted]",
    externalUrl: "https://alphafold.ebi.ac.uk/entry/P38398",
  },
  {
    id: "PCSK9",
    name: "Proprotein Convertase Subtilisin/Kexin Type 9",
    uniprotId: "Q8NBP7",
    pdbId: "2P4E",
    category: "Cardiovascular",
    description: "Key regulator of plasma cholesterol levels through the degradation of low-density lipoprotein receptors.",
    meanPLDDT: 93.8,
    residues: 692,
    provenance: "[RCSB PDB Experimental]",
    externalUrl: "https://www.rcsb.org/structure/2P4E",
  },
];

export const BioScienceLab: React.FC = () => {
  const [selectedTarget, setSelectedTarget] = useState<MoleculeTarget>(PRESET_TARGETS[0]);
  const mountRef = useRef<HTMLDivElement | null>(null);

  // 3D Three.js Molecular Structure Visualizer
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#0B0A10");

    const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.1, 100);
    camera.position.set(0, 0, 18);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Lighting
    const ambient = new THREE.AmbientLight("#FFFFFF", 0.6);
    scene.add(ambient);
    const dirLight = new THREE.DirectionalLight("#FFFFFF", 1.8);
    dirLight.position.set(10, 12, 10);
    scene.add(dirLight);

    // Procedural Alpha-Helix and Ribbon Backbone Model
    const molGroup = new THREE.Group();

    // Generate procedural helical protein backbone
    const helixPoints: THREE.Vector3[] = [];
    const turns = 8;
    const pointsPerTurn = 16;
    for (let i = 0; i < turns * pointsPerTurn; i++) {
      const angle = (i / pointsPerTurn) * Math.PI * 2;
      const radius = 2.4 + Math.sin(i * 0.1) * 0.6;
      const y = (i / (turns * pointsPerTurn)) * 14 - 7;
      helixPoints.push(new THREE.Vector3(Math.cos(angle) * radius, y, Math.sin(angle) * radius));
    }

    const curve = new THREE.CatmullRomCurve3(helixPoints);
    const tubeGeo = new THREE.TubeGeometry(curve, 120, 0.28, 12, false);

    // Canonical AlphaFold pLDDT Colors
    const plddtColor =
      selectedTarget.meanPLDDT >= 90
        ? "#0053D6" // Very High deep blue
        : selectedTarget.meanPLDDT >= 70
        ? "#65CBF3" // Confident light blue
        : selectedTarget.meanPLDDT >= 50
        ? "#FFDB13" // Low yellow
        : "#FF7D45"; // Very Low orange

    const tubeMat = new THREE.MeshStandardMaterial({
      color: plddtColor,
      roughness: 0.3,
      metalness: 0.4,
    });
    const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
    molGroup.add(tubeMesh);

    // Chemical ligand pocket spheres
    const sphereGeo = new THREE.SphereGeometry(0.35, 16, 16);
    const atomColors = ["#EF4444", "#38BDF8", "#FBBF24", "#34D399"];
    for (let i = 0; i < 30; i++) {
      const mat = new THREE.MeshStandardMaterial({
        color: atomColors[i % atomColors.length],
        metalness: 0.2,
        roughness: 0.4,
      });
      const atom = new THREE.Mesh(sphereGeo, mat);
      const pt = helixPoints[i * 4] || new THREE.Vector3();
      atom.position.copy(pt).add(new THREE.Vector3((Math.random() - 0.5) * 1.5, (Math.random() - 0.5) * 1.5, (Math.random() - 0.5) * 1.5));
      molGroup.add(atom);
    }

    scene.add(molGroup);

    let animId = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      molGroup.rotation.y += 0.008;
      molGroup.rotation.x = Math.sin(Date.now() * 0.001) * 0.15;
      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", onResize);
      renderer.dispose();
      tubeGeo.dispose();
      tubeMat.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [selectedTarget]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-purple-500/10 pb-5 mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Dna className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-purple-100 flex items-center gap-2">
                BioScience Discovery Lab & AlphaFold Structural Viewer
                <Sparkles className="w-4 h-4 text-purple-400" />
              </h3>
              <p className="text-xs text-gray-400">
                Ground your arcade reflexes in biological computing: 3D AlphaFold protein conformations, pLDDT metrics, and target synthesis
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-purple-300 bg-purple-500/10 px-3 py-1.5 rounded-xl border border-purple-500/20">
            DeepMind Science Skills
          </span>
        </div>

        {/* Quick-Try Example Pill Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-5 text-xs">
          <span className="text-gray-400 font-mono text-[11px] uppercase whitespace-nowrap">Target Presets:</span>
          {PRESET_TARGETS.map((target) => (
            <button
              key={target.id}
              onClick={() => setSelectedTarget(target)}
              className={`px-3 py-1.5 rounded-xl font-mono font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                selectedTarget.id === target.id
                  ? "bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm"
                  : "bg-[#0B0A10] text-gray-400 border border-purple-500/10 hover:text-gray-200"
              }`}
            >
              <span>🧬 {target.id}</span>
              <span className="text-[10px] text-purple-400">({target.pdbId})</span>
            </button>
          ))}
        </div>

        {/* 2-Column Split: 3D Visualizer & Scientific Metadata */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: 3D Protein Canvas */}
          <div className="relative h-[380px] bg-[#0B0A10] rounded-2xl border border-purple-500/20 overflow-hidden shadow-inner">
            <div ref={mountRef} className="w-full h-full block" />
            <div className="absolute top-3 left-3 bg-[#12101A]/80 backdrop-blur-sm border border-purple-500/20 px-3 py-1 rounded-lg text-[11px] font-mono text-purple-300">
              3D PBR Backbone · Interactive Rotation
            </div>
            <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[10px] font-mono text-gray-400 bg-[#12101A]/80 px-3 py-1.5 rounded-lg border border-purple-500/10">
              <span>UniProt: {selectedTarget.uniprotId}</span>
              <span>PDB: {selectedTarget.pdbId}</span>
              <span className="text-purple-300">{selectedTarget.provenance}</span>
            </div>
          </div>

          {/* Right: Scientific Inspector */}
          <div className="space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  {selectedTarget.category}
                </span>
                <a
                  href={selectedTarget.externalUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-purple-400 hover:text-purple-200 flex items-center gap-1 font-mono transition-colors"
                >
                  Source Record <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <h4 className="text-lg font-bold text-white">{selectedTarget.name}</h4>
              <p className="text-xs text-gray-400 leading-relaxed">{selectedTarget.description}</p>

              {/* AlphaFold 4-band pLDDT Confidence Scale */}
              <div className="bg-[#0B0A10] border border-purple-500/20 rounded-xl p-3.5 space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-gray-400">Mean pLDDT Confidence:</span>
                  <span className="font-bold text-cyan-300">{selectedTarget.meanPLDDT} / 100</span>
                </div>

                <div className="h-2 rounded-full overflow-hidden flex bg-gray-800">
                  <div className="h-full bg-[#0053D6]" style={{ width: "40%" }} title="Very High (>90)" />
                  <div className="h-full bg-[#65CBF3]" style={{ width: "30%" }} title="Confident (70-90)" />
                  <div className="h-full bg-[#FFDB13]" style={{ width: "20%" }} title="Low (50-70)" />
                  <div className="h-full bg-[#FF7D45]" style={{ width: "10%" }} title="Very Low (<50)" />
                </div>

                <div className="grid grid-cols-4 text-[9px] font-mono text-gray-400 text-center pt-1">
                  <span className="text-[#0053D6] font-bold">&gt;90 Very High</span>
                  <span className="text-[#65CBF3] font-bold">70-90 Confident</span>
                  <span className="text-[#FFDB13] font-bold">50-70 Low</span>
                  <span className="text-[#FF7D45] font-bold">&lt;50 Very Low</span>
                </div>
              </div>

              {/* Bio-Orb Power Transfer Link */}
              <div className="bg-purple-950/20 border border-purple-500/30 rounded-xl p-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-purple-400" />
                  <span className="text-purple-200">Synthesize Bio-Orb for Arena:</span>
                </div>
                <span className="font-mono font-bold text-amber-300">+250 Overdrive Energy</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
