import React, { useState } from "react";
import type { GameHistoryEntry, GameType } from "../types/game";
import { TrendingUp, Award, Zap, Clock, ShieldCheck, History, Filter } from "lucide-react";

interface Props {
  history: GameHistoryEntry[];
  currentScore?: number;
  onClearHistory?: () => void;
}

export const RatingHistoryGraph: React.FC<Props> = ({ history, currentScore = 0 }) => {
  const [selectedGameFilter, setSelectedGameFilter] = useState<string>("all");
  const [hoveredEntry, setHoveredEntry] = useState<GameHistoryEntry | null>(null);

  const filteredHistory = history.filter((item) => {
    if (selectedGameFilter === "all") return true;
    return item.gameType === selectedGameFilter;
  });

  const allTimeBest = history.reduce((max, h) => Math.max(max, h.winnerScore), 0);
  const currentRating = history.length > 0 ? history[history.length - 1].ratingAfter : 1200;
  const initialRating = history.length > 0 ? history[0].ratingAfter : 1200;
  const netRatingDelta = currentRating - initialRating;
  const avgAccuracy = history.length > 0
    ? Math.round(history.reduce((sum, h) => sum + h.accuracyPercent, 0) / history.length)
    : 85;

  // Chart dimensions
  const chartWidth = 740;
  const chartHeight = 220;
  const paddingX = 40;
  const paddingY = 30;

  const points = filteredHistory.map((item, idx) => {
    const minRating = Math.min(...filteredHistory.map((h) => h.ratingAfter), 1000) - 50;
    const maxRating = Math.max(...filteredHistory.map((h) => h.ratingAfter), 1600) + 50;
    const range = Math.max(maxRating - minRating, 100);

    const x =
      filteredHistory.length > 1
        ? paddingX + (idx / (filteredHistory.length - 1)) * (chartWidth - paddingX * 2)
        : chartWidth / 2;
    const y =
      chartHeight -
      paddingY -
      ((item.ratingAfter - minRating) / range) * (chartHeight - paddingY * 2);

    return { x, y, item };
  });

  const pathD =
    points.length > 0
      ? points.reduce((acc, pt, i) => {
          return i === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`;
        }, "")
      : "";

  const areaD =
    points.length > 0
      ? `${pathD} L ${points[points.length - 1].x} ${chartHeight - paddingY} L ${points[0].x} ${chartHeight - paddingY} Z`
      : "";

  return (
    <div className="space-y-6">
      {/* Top Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-[#12101A] border border-purple-500/20 rounded-xl p-4 flex items-center justify-between shadow-lg">
          <div>
            <div className="text-xs uppercase tracking-wider text-purple-300/70 font-mono">Pilot Rating</div>
            <div className="text-2xl font-bold text-purple-100 flex items-center gap-1.5 mt-0.5">
              {currentRating}
              <span className={`text-xs px-1.5 py-0.5 rounded ${netRatingDelta >= 0 ? "bg-emerald-500/20 text-emerald-400" : "bg-rose-500/20 text-rose-400"}`}>
                {netRatingDelta >= 0 ? `+${netRatingDelta}` : netRatingDelta}
              </span>
            </div>
            <div className="text-[11px] text-gray-400 mt-0.5">Chess.com ELO scale</div>
          </div>
          <div className="p-3 bg-purple-500/10 rounded-lg text-purple-400">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#12101A] border border-purple-500/20 rounded-xl p-4 flex items-center justify-between shadow-lg">
          <div>
            <div className="text-xs uppercase tracking-wider text-purple-300/70 font-mono">All-Time Best</div>
            <div className="text-2xl font-bold text-amber-300 mt-0.5">{allTimeBest.toLocaleString()}</div>
            <div className="text-[11px] text-gray-400 mt-0.5">Current run: {currentScore} pts</div>
          </div>
          <div className="p-3 bg-amber-500/10 rounded-lg text-amber-400">
            <Award className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#12101A] border border-purple-500/20 rounded-xl p-4 flex items-center justify-between shadow-lg">
          <div>
            <div className="text-xs uppercase tracking-wider text-purple-300/70 font-mono">Average Accuracy</div>
            <div className="text-2xl font-bold text-cyan-300 mt-0.5">{avgAccuracy}%</div>
            <div className="text-[11px] text-gray-400 mt-0.5">Dodge & orb collection</div>
          </div>
          <div className="p-3 bg-cyan-500/10 rounded-lg text-cyan-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#12101A] border border-purple-500/20 rounded-xl p-4 flex items-center justify-between shadow-lg">
          <div>
            <div className="text-xs uppercase tracking-wider text-purple-300/70 font-mono">Total Runs Logged</div>
            <div className="text-2xl font-bold text-purple-200 mt-0.5">{history.length}</div>
            <div className="text-[11px] text-gray-400 mt-0.5">Across 3 game arenas</div>
          </div>
          <div className="p-3 bg-purple-500/10 rounded-lg text-purple-300">
            <Zap className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Chess.com-Style Rating Trajectory Graph */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-5 shadow-2xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-lg font-bold text-purple-100 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-purple-400" />
              Pilot Rating & Performance Trajectory
            </h3>
            <p className="text-xs text-gray-400">
              Interactive ELO curve recording score progression, reflex spikes, and match outcomes
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 bg-[#0B0A10] p-1 rounded-lg border border-purple-500/20 text-xs">
            <Filter className="w-3.5 h-3.5 text-purple-400 ml-1.5" />
            <button
              onClick={() => setSelectedGameFilter("all")}
              className={`px-2.5 py-1 rounded-md transition-colors ${selectedGameFilter === "all" ? "bg-purple-600/30 text-purple-200 font-medium" : "text-gray-400 hover:text-gray-200"}`}
            >
              All
            </button>
            <button
              onClick={() => setSelectedGameFilter("racing")}
              className={`px-2.5 py-1 rounded-md transition-colors ${selectedGameFilter === "racing" ? "bg-purple-600/30 text-purple-200 font-medium" : "text-gray-400 hover:text-gray-200"}`}
            >
              🏎️ Racing
            </button>
            <button
              onClick={() => setSelectedGameFilter("ball_balance")}
              className={`px-2.5 py-1 rounded-md transition-colors ${selectedGameFilter === "ball_balance" ? "bg-purple-600/30 text-purple-200 font-medium" : "text-gray-400 hover:text-gray-200"}`}
            >
              🔮 Ball Ascent
            </button>
            <button
              onClick={() => setSelectedGameFilter("maze_hunter")}
              className={`px-2.5 py-1 rounded-md transition-colors ${selectedGameFilter === "maze_hunter" ? "bg-purple-600/30 text-purple-200 font-medium" : "text-gray-400 hover:text-gray-200"}`}
            >
              👾 Maze Hunter
            </button>
          </div>
        </div>

        {/* SVG Chart */}
        <div className="relative w-full overflow-x-auto">
          <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto min-w-[500px]">
            <defs>
              <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#C4B5FD" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#A78BFA" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Grid horizontal guidelines */}
            {[0.2, 0.4, 0.6, 0.8].map((ratio) => {
              const y = paddingY + (chartHeight - paddingY * 2) * ratio;
              return (
                <line
                  key={ratio}
                  x1={paddingX}
                  y1={y}
                  x2={chartWidth - paddingX}
                  y2={y}
                  stroke="rgba(196, 181, 253, 0.08)"
                  strokeDasharray="4 4"
                />
              );
            })}

            {/* Area Fill */}
            {areaD && <path d={areaD} fill="url(#chartGradient)" />}

            {/* Trajectory Line */}
            {pathD && (
              <path
                d={pathD}
                fill="none"
                stroke="#C4B5FD"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}

            {/* Data Points */}
            {points.map((pt, i) => (
              <g key={i} className="cursor-pointer" onMouseEnter={() => setHoveredEntry(pt.item)}>
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r="4"
                  fill="#12101A"
                  stroke="#C4B5FD"
                  strokeWidth="2"
                  className="transition-transform hover:scale-150"
                />
              </g>
            ))}
          </svg>

          {/* Hover Details Popup */}
          {hoveredEntry && (
            <div className="mt-2 p-3 bg-[#0B0A10] border border-purple-500/30 rounded-xl text-xs flex flex-wrap items-center justify-between gap-3 shadow-xl">
              <div className="flex items-center gap-2">
                <span className="text-xl">{hoveredEntry.winnerEmoji}</span>
                <div>
                  <div className="font-bold text-purple-200">
                    {hoveredEntry.winnerName} · {hoveredEntry.playerMode}
                  </div>
                  <div className="text-[11px] text-gray-400">{hoveredEntry.dateStr}</div>
                </div>
              </div>
              <div className="flex items-center gap-4 text-gray-300">
                <div>
                  <span className="text-gray-400">Score:</span>{" "}
                  <span className="font-bold text-amber-300">{hoveredEntry.winnerScore.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-gray-400">Rating:</span>{" "}
                  <span className="font-bold text-purple-300">{hoveredEntry.ratingAfter}</span>{" "}
                  <span className={hoveredEntry.ratingDelta >= 0 ? "text-emerald-400" : "text-rose-400"}>
                    ({hoveredEntry.ratingDelta >= 0 ? `+${hoveredEntry.ratingDelta}` : hoveredEntry.ratingDelta})
                  </span>
                </div>
                <div>
                  <span className="text-gray-400">Duration:</span>{" "}
                  <span className="text-white">{hoveredEntry.durationSeconds}s</span>
                </div>
                <div>
                  <span className="text-gray-400">Status:</span>{" "}
                  <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-200">{hoveredEntry.status}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Recent Match Log Table */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-5 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-sm font-bold text-purple-200 uppercase tracking-wider font-mono flex items-center gap-2">
            <History className="w-4 h-4 text-purple-400" />
            Detailed Match Log
          </h4>
          <span className="text-xs text-gray-400">{filteredHistory.length} matches recorded</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0B0A10] text-purple-300/70 border-b border-purple-500/10">
              <tr>
                <th className="py-2.5 px-3">Date & Mode</th>
                <th className="py-2.5 px-3">Arena Game</th>
                <th className="py-2.5 px-3">Winner / Pilot</th>
                <th className="py-2.5 px-3">Score</th>
                <th className="py-2.5 px-3">Rating Change</th>
                <th className="py-2.5 px-3">Accuracy</th>
                <th className="py-2.5 px-3">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-500/10 text-gray-300">
              {filteredHistory.slice(-8).reverse().map((entry) => (
                <tr key={entry.id} className="hover:bg-purple-500/5 transition-colors">
                  <td className="py-2.5 px-3 font-mono text-gray-400">
                    <div>{entry.dateStr}</div>
                    <div className="text-[10px] text-purple-300">{entry.playerMode}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                      {entry.gameType === "racing"
                        ? "🏎️ Racing"
                        : entry.gameType === "ball_balance"
                        ? "🔮 Ball Ascent"
                        : "👾 Maze Hunter"}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-medium text-white flex items-center gap-1.5">
                    <span>{entry.winnerEmoji}</span>
                    <span>{entry.winnerName}</span>
                  </td>
                  <td className="py-2.5 px-3 font-bold text-amber-300">{entry.winnerScore.toLocaleString()}</td>
                  <td className="py-2.5 px-3 font-mono">
                    <span className={entry.ratingDelta >= 0 ? "text-emerald-400" : "text-rose-400"}>
                      {entry.ratingDelta >= 0 ? `+${entry.ratingDelta}` : entry.ratingDelta}
                    </span>{" "}
                    <span className="text-gray-400 text-[10px]">({entry.ratingAfter})</span>
                  </td>
                  <td className="py-2.5 px-3">{entry.accuracyPercent}%</td>
                  <td className="py-2.5 px-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {entry.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
