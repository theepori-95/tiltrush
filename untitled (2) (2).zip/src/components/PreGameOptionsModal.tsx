import React from "react";
import type { GameSettings, PlayerConfig, PlayerId, GameType } from "../types/game";
import { AVAILABLE_EMOJIS } from "../types/game";
import { Settings, Play, Users, Gauge, Gamepad2, Volume2, VolumeX, Sparkles } from "lucide-react";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (updater: (prev: GameSettings) => GameSettings) => void;
  playerConfigs: Record<PlayerId, PlayerConfig>;
  onUpdatePlayerConfig: (pid: PlayerId, patch: Partial<PlayerConfig>) => void;
  onStartGame: () => void;
}

export const PreGameOptionsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  playerConfigs,
  onUpdatePlayerConfig,
  onStartGame,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0A10]/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#12101A] border border-purple-500/30 rounded-3xl max-w-2xl w-full p-6 md:p-8 shadow-2xl space-y-6 my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-purple-500/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-purple-100 flex items-center gap-2">
                Pre-Game Arena Configuration
                <Sparkles className="w-4 h-4 text-purple-400" />
              </h2>
              <p className="text-xs text-gray-400">Configure your game mode, multiplayer lobby, and player avatars</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-200 text-lg px-2 py-1 rounded-lg"
          >
            ✕
          </button>
        </div>

        {/* Section 1: Choose Arena Game Type */}
        <div className="space-y-2.5">
          <label className="text-xs font-mono uppercase tracking-wider text-purple-300 font-bold flex items-center gap-1.5">
            <Gamepad2 className="w-4 h-4" /> 1. Select Arena Game Mode
          </label>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              {
                id: "racing",
                title: "NEON RACING",
                desc: "High-speed hovercraft runner with Pulse Orbs & Overdrive",
                emoji: "🏎️",
                border: "border-purple-500/30",
              },
              {
                id: "ball_balance",
                title: "BALL ASCENT & JUMP",
                desc: "Balance rising sphere & press JUMP to leap over roof crushers",
                emoji: "🔮",
                border: "border-cyan-500/30",
              },
              {
                id: "maze_hunter",
                title: "MAZE HUNTER CHASE",
                desc: "Pac-Man style maze, devour pellets, find Key & escape Stalker",
                emoji: "👾",
                border: "border-rose-500/30",
              },
            ].map((game) => (
              <button
                key={game.id}
                onClick={() => onUpdateSettings((s) => ({ ...s, gameType: game.id as GameType }))}
                className={`p-4 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                  settings.gameType === game.id
                    ? "bg-purple-900/30 border-purple-400 shadow-lg shadow-purple-500/10 scale-[1.02]"
                    : "bg-[#0B0A10] border-purple-500/10 hover:border-purple-500/30"
                }`}
              >
                <div>
                  <div className="text-2xl mb-2">{game.emoji}</div>
                  <div className="text-sm font-bold text-purple-100">{game.title}</div>
                  <div className="text-[11px] text-gray-400 mt-1 leading-snug">{game.desc}</div>
                </div>
                {settings.gameType === game.id && (
                  <div className="mt-3 text-[10px] font-mono font-bold text-purple-300 uppercase">
                    ✓ Selected
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Section 2: Multiplayer Mode */}
        <div className="space-y-2.5">
          <label className="text-xs font-mono uppercase tracking-wider text-purple-300 font-bold flex items-center gap-1.5">
            <Users className="w-4 h-4" /> 2. Multiplayer Split-Screen Players
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { count: 1, label: "1P Solo Run", tag: "Single Player" },
              { count: 2, label: "2P Split Duel", tag: "Split Screen" },
              { count: 3, label: "3P Trio Rush", tag: "3-Way Battle" },
              { count: 4, label: "4P Quad Royale", tag: "Party Arena" },
            ].map((m) => (
              <button
                key={m.count}
                onClick={() =>
                  onUpdateSettings((s) => ({ ...s, playerCount: m.count as 1 | 2 | 3 | 4 }))
                }
                className={`p-3 rounded-xl border text-center transition-all ${
                  settings.playerCount === m.count
                    ? "bg-purple-600/30 border-purple-400 text-purple-100"
                    : "bg-[#0B0A10] border-purple-500/10 text-gray-400 hover:text-gray-200"
                }`}
              >
                <div className="font-bold text-sm">{m.label}</div>
                <div className="text-[10px] text-purple-300/80 mt-0.5">{m.tag}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Section 3: Player Customizer (Name & Emoji) */}
        <div className="space-y-2.5">
          <label className="text-xs font-mono uppercase tracking-wider text-purple-300 font-bold">
            3. Player Customization (Names & Emojis)
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {([1, 2, 3, 4] as PlayerId[]).slice(0, settings.playerCount).map((pid) => {
              const cfg = playerConfigs[pid];
              return (
                <div
                  key={pid}
                  className="p-3 bg-[#0B0A10] border rounded-xl flex items-center justify-between gap-3"
                  style={{ borderColor: `${cfg.color}40` }}
                >
                  <div className="flex items-center gap-2">
                    <select
                      value={cfg.emoji}
                      onChange={(e) => onUpdatePlayerConfig(pid, { emoji: e.target.value })}
                      className="bg-[#191622] text-xl border border-purple-500/30 rounded-lg p-1.5 cursor-pointer"
                    >
                      {AVAILABLE_EMOJIS.map((em) => (
                        <option key={em} value={em}>
                          {em}
                        </option>
                      ))}
                    </select>
                    <div>
                      <input
                        type="text"
                        value={cfg.name}
                        onChange={(e) => onUpdatePlayerConfig(pid, { name: e.target.value })}
                        className="bg-transparent text-sm font-bold text-white border-b border-purple-500/30 focus:border-purple-400 outline-none w-28"
                      />
                      <div className="text-[10px] font-mono" style={{ color: cfg.color }}>
                        Player {pid} Slot
                      </div>
                    </div>
                  </div>
                  <div
                    className="w-4 h-4 rounded-full shadow-lg"
                    style={{ backgroundColor: cfg.color }}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Section 4: Speed Mode & Sound */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="text-xs font-mono uppercase tracking-wider text-purple-300 font-bold flex items-center gap-1.5 mb-2">
              <Gauge className="w-4 h-4" /> Difficulty / Speed
            </label>
            <div className="flex gap-2">
              {(["chill", "neon", "warp"] as const).map((spd) => (
                <button
                  key={spd}
                  onClick={() => onUpdateSettings((s) => ({ ...s, speedMode: spd }))}
                  className={`flex-1 py-1.5 px-2 rounded-lg border text-xs capitalize ${
                    settings.speedMode === spd
                      ? "bg-purple-600/30 border-purple-400 text-white font-bold"
                      : "bg-[#0B0A10] border-purple-500/10 text-gray-400"
                  }`}
                >
                  {spd}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-mono uppercase tracking-wider text-purple-300 font-bold flex items-center gap-1.5 mb-2">
              <Volume2 className="w-4 h-4" /> Web Audio FX
            </label>
            <button
              onClick={() => onUpdateSettings((s) => ({ ...s, soundEnabled: !s.soundEnabled }))}
              className={`w-full py-1.5 px-3 rounded-lg border text-xs flex items-center justify-center gap-2 ${
                settings.soundEnabled
                  ? "bg-purple-600/20 border-purple-400 text-purple-200"
                  : "bg-[#0B0A10] border-purple-500/10 text-gray-500"
              }`}
            >
              {settings.soundEnabled ? <Volume2 className="w-4 h-4 text-purple-400" /> : <VolumeX className="w-4 h-4" />}
              {settings.soundEnabled ? "Arcade Sounds ON" : "Muted"}
            </button>
          </div>
        </div>

        {/* Action Button: Start Match */}
        <div className="border-t border-purple-500/10 pt-5 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-[#191622] hover:bg-purple-900/30 text-gray-300 text-sm font-medium border border-purple-500/20"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onClose();
              onStartGame();
            }}
            className="px-8 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-bold text-sm shadow-xl shadow-purple-500/25 flex items-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" />
            ENTER ARENA & LAUNCH
          </button>
        </div>
      </div>
    </div>
  );
};
