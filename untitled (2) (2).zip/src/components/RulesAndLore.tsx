import React from "react";
import { BookOpen, Smartphone, Compass, ShieldAlert, Cpu, Sparkles, Zap, ArrowUp } from "lucide-react";

export const RulesAndLore: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="bg-[#12101A] border border-purple-500/20 rounded-2xl p-6 shadow-2xl">
        <div className="flex items-center gap-3 border-b border-purple-500/10 pb-4 mb-5">
          <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-purple-100 flex items-center gap-2">
              TiltRush Operational Manual & Lore
              <Sparkles className="w-4 h-4 text-purple-400" />
            </h3>
            <p className="text-xs text-gray-400">
              The complete guide to real-time motion steering, multi-arena mechanics, and pairing technology
            </p>
          </div>
        </div>

        {/* 3 Game Rules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
          <div className="bg-[#0B0A10] border border-purple-500/20 rounded-2xl p-5 space-y-3">
            <div className="text-3xl">🏎️</div>
            <h4 className="font-bold text-base text-purple-200">Arena 1: Neon Racing</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              Pilot a supersonic hovercraft down a dark infinite highway. Tilt your phone left and right to weave through barrier walls.
            </p>
            <ul className="text-xs text-gray-300 space-y-1.5 list-disc list-inside">
              <li><strong className="text-purple-300">Tilt-to-Flow:</strong> Dynamic lavender particle trails scale with steering velocity.</li>
              <li><strong className="text-purple-300">Pulse Orbs:</strong> Collect orbs for up to 5x combo multiplier.</li>
              <li><strong className="text-purple-300">Neon Overdrive:</strong> 3 orbs charge the hyperdrive to smash through obstacles!</li>
            </ul>
          </div>

          <div className="bg-[#0B0A10] border border-cyan-500/20 rounded-2xl p-5 space-y-3">
            <div className="text-3xl">🔮</div>
            <h4 className="font-bold text-base text-cyan-200">Arena 2: Ball Ascent & Jump</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              Balance a levitating sphere against thermal updrafts while roof crushers and spiked stalactites fall from the ceiling.
            </p>
            <ul className="text-xs text-gray-300 space-y-1.5 list-disc list-inside">
              <li><strong className="text-cyan-300">Balance Tilt:</strong> Fine phone roll controls lateral positioning.</li>
              <li><strong className="text-cyan-300">The JUMP Button:</strong> Press JUMP on your phone or Space on laptop to leap over falling roof obstacles!</li>
              <li><strong className="text-cyan-300">Altitude Score:</strong> Climb higher for escalating rating points.</li>
            </ul>
          </div>

          <div className="bg-[#0B0A10] border border-rose-500/20 rounded-2xl p-5 space-y-3">
            <div className="text-3xl">👾</div>
            <h4 className="font-bold text-base text-rose-200">Arena 3: Cyber Maze Hunter</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              Pac-Man style cyber maze where an autonomous AI Hunter relentlessly pursues players through glowing corridors.
            </p>
            <ul className="text-xs text-gray-300 space-y-1.5 list-disc list-inside">
              <li><strong className="text-rose-300">2D Gyro Navigation:</strong> Tilt roll (left/right) and pitch (up/down) to choose turns.</li>
              <li><strong className="text-rose-300">Golden Key:</strong> Retrieve the Access Key in the center of the labyrinth.</li>
              <li><strong className="text-rose-300">Exit Escape:</strong> Reach the Exit Portal to clear the sector and earn +1000 points!</li>
            </ul>
          </div>
        </div>

        {/* Sensor & Pairing Technical Specs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-3 border-t border-purple-500/10">
          <div className="bg-[#0B0A10] border border-purple-500/20 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-purple-300 font-bold text-sm">
              <Compass className="w-4 h-4" /> Real Gyroscope Normalization
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              TiltRush reads real <code className="text-purple-200 font-mono">DeviceOrientationEvent</code> gamma and beta degrees. During calibration, the player's natural resting tilt angle is zeroed out as the neutral horizon, clamping values into a smooth -1.0 to +1.0 control curve throttled at 30 Hz.
            </p>
          </div>

          <div className="bg-[#0B0A10] border border-purple-500/20 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-purple-300 font-bold text-sm">
              <Cpu className="w-4 h-4" /> Full-Stack WebSocket Architecture
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              Built on a unified Node.js + Express + ws WebSocket engine on port 3000. In-memory room registries route individual phone sockets to designated player slots (P1 to P4) with sub-10ms round-trip latency (RTT) tracking.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
