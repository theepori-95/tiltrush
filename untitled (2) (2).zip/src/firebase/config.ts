import { initializeApp, getApps, type FirebaseApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, type Auth, type User } from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc, collection, query, where, getDocs, type Firestore } from "firebase/firestore";

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

// Attempt to load from firebase-applet-config.json if available
try {
  // @ts-expect-error dynamic import of generated config
  import("../../firebase-applet-config.json").then((configModule) => {
    const config = configModule.default || configModule;
    if (config && config.apiKey && !getApps().length) {
      app = initializeApp(config);
      auth = getAuth(app);
      db = getFirestore(app, config.firestoreDatabaseId);
    }
  }).catch(() => {
    // Config not yet provisioned
  });
} catch {
  // Not provisioned yet
}

export function getFirebaseAuth(): Auth | null {
  if (!auth && getApps().length > 0) {
    auth = getAuth(getApps()[0]);
  }
  return auth;
}

export function getFirebaseDb(): Firestore | null {
  if (!db && getApps().length > 0) {
    db = getFirestore(getApps()[0]);
  }
  return db;
}

export async function signInWithGoogle(): Promise<User | null> {
  const currentAuth = getFirebaseAuth();
  if (!currentAuth) {
    throw new Error("Firebase Authentication is not yet provisioned. Please complete Firebase setup.");
  }
  const provider = new GoogleAuthProvider();
  const result = await signInWithPopup(currentAuth, provider);
  return result.user;
}

export async function logOut(): Promise<void> {
  const currentAuth = getFirebaseAuth();
  if (currentAuth) {
    await signOut(currentAuth);
  }
}
