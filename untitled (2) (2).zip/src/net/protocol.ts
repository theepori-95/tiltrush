import type { PlayerId, GameType } from "../types/game";

export type ClientToServerMsg =
  | { t: "create"; room: string }
  | { t: "join"; room: string; player: PlayerId }
  | { t: "tilt"; room: string; player: PlayerId; x: number; y?: number; seq: number }
  | { t: "action"; room: string; player: PlayerId; actionType: "jump" | "overdrive" | "sprint" }
  | { t: "calibrate"; room: string; player: PlayerId; roll: number; pitch?: number }
  | { t: "ping"; room: string; player: PlayerId; id: number }
  | { t: "pong"; room: string; player: PlayerId; id: number };

export type ServerToClientMsg =
  | { t: "created"; room: string; qr?: string }
  | { t: "joined"; room: string; player: PlayerId }
  | { t: "player_connected"; room: string; player: PlayerId }
  | { t: "player_disconnected"; room: string; player: PlayerId }
  | { t: "game_select"; gameType: GameType }
  | { t: "tilt"; player: PlayerId; x: number; y?: number; seq: number }
  | { t: "action"; player: PlayerId; actionType: "jump" | "overdrive" | "sprint" }
  | { t: "calibrate"; player: PlayerId; roll: number; pitch?: number }
  | { t: "ping"; id: number }
  | { t: "pong"; id: number; rtt: number }
  | { t: "error"; message: string };
