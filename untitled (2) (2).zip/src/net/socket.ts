import type { ClientToServerMsg, ServerToClientMsg } from "./protocol";
import type { PlayerId } from "../types/game";

export type SocketEventHandler = (msg: ServerToClientMsg) => void;

export class GameSocketClient {
  private ws: WebSocket | null = null;
  private url: string;
  private listeners = new Set<SocketEventHandler>();
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private pingInterval: ReturnType<typeof setInterval> | null = null;
  private reconnectAttempts = 0;
  private isDestroyed = false;
  private lastPingSent = 0;
  public rtt = 0;
  public isConnected = false;

  constructor(endpointPath = "/ws") {
    if (typeof window !== "undefined") {
      const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
      const host = window.location.host;
      this.url = `${proto}//${host}${endpointPath}`;
    } else {
      this.url = "ws://localhost:3000/ws";
    }
  }

  public connect(onOpen?: () => void) {
    if (this.isDestroyed || typeof window === "undefined") return;

    try {
      this.ws = new WebSocket(this.url);

      this.ws.onopen = () => {
        this.isConnected = true;
        this.reconnectAttempts = 0;
        if (onOpen) onOpen();
        this.startPing();
      };

      this.ws.onmessage = (event) => {
        try {
          const msg: ServerToClientMsg = JSON.parse(event.data);
          if (msg.t === "pong") {
            if (this.lastPingSent > 0) {
              const now = Date.now();
              const measuredRtt = now - this.lastPingSent;
              this.rtt = Math.max(1, Math.min(999, measuredRtt));
            }
          }
          this.listeners.forEach((cb) => cb(msg));
        } catch (e) {
          console.error("WS error parsing message", e);
        }
      };

      this.ws.onclose = () => {
        this.isConnected = false;
        this.stopPing();
        this.scheduleReconnect();
      };

      this.ws.onerror = () => {
        if (this.ws) {
          this.ws.close();
        }
      };
    } catch {
      this.scheduleReconnect();
    }
  }

  private startPing() {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.lastPingSent = Date.now();
        this.send({
          t: "ping",
          room: "",
          player: 1,
          id: this.lastPingSent,
        });
      }
    }, 1200);
  }

  private stopPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private scheduleReconnect() {
    if (this.isDestroyed || this.reconnectTimer) return;
    this.reconnectAttempts++;
    const delay = Math.min(5000, 1000 * Math.pow(1.5, Math.min(this.reconnectAttempts, 5)));
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, delay);
  }

  public send(msg: ClientToServerMsg) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
    }
  }

  public subscribe(handler: SocketEventHandler) {
    this.listeners.add(handler);
    return () => this.listeners.delete(handler);
  }

  public destroy() {
    this.isDestroyed = true;
    this.stopPing();
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.listeners.clear();
  }
}
